# bev_od_det_cnn

## 项目概述

- 项目目标：输入多路视角下的相机图像，将图像的特征转化为bev视角下的特征，输出bev视角下的目标位置
- 整体方案：输入多路视角下的相机图像，首先将图像进行特征提取，生成2D feature。其次将2D feature转化为3D feature。最后在3D feature上进行目标检测
- 目前进展：基本完成算法基础模块，后续需要加入实车数据进行测试。

## 代码
### 目录结构
```
	# 示例
	${ROOT}
	├── fiery
	├── train.py
	├── visualkise.py
	├── evaluate.py
	├── Readme.md
	└── environment.yml
```

### 运行环境

- python=3.7
- pytorch=1.7.0

### 使用方法
- 模型训练脚本使用 ‘sh run.sh‘
- 模型推理脚本使用 ‘sh demo.sh‘

## To Do
- [ ] 优化模型的角度识别，详见：http://10.94.38.105/visual_object_detection/2d_objectdetection/aroundview/fisheye_od_detect/issues/14

## 历史版本

- 2021/12/06: 模型在bev下输出目标物的中心点，角度，长宽


## 团队
- 3D OD模型开发小组

