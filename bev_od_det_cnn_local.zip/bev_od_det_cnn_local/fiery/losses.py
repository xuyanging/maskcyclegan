import torch
import torch.nn as nn
import torch.nn.functional as F


class SpatialRegressionLoss(nn.Module):
    def __init__(self, norm, ignore_index=255, future_discount=1.0):
        super(SpatialRegressionLoss, self).__init__()
        self.norm = norm
        self.ignore_index = ignore_index
        self.future_discount = future_discount

        if norm == 1:
            self.loss_fn = F.l1_loss
        elif norm == 2:
            self.loss_fn = F.mse_loss
        else:
            raise ValueError(f'Expected norm 1 or 2, but got norm={norm}')

    def forward(self, prediction, target):
        assert len(prediction.shape) == 5, 'Must be a 5D tensor'
        # ignore_index is the same across all channels
        mask = target[:, :, :1] != self.ignore_index
        if mask.sum() == 0:
            return prediction.new_zeros(1)[0].float()

        loss = self.loss_fn(prediction, target, reduction='none')

        # Sum channel dimension
        loss = torch.sum(loss, dim=-3, keepdims=True)

        seq_len = loss.shape[1]
        future_discounts = self.future_discount ** torch.arange(seq_len, device=loss.device, dtype=loss.dtype)
        future_discounts = future_discounts.view(1, seq_len, 1, 1, 1)
        loss = loss * future_discounts

        return loss[mask].mean()


class SegmentationLoss(nn.Module):
    def __init__(self, class_weights, ignore_index=255, use_top_k=False, top_k_ratio=1.0, future_discount=1.0):
        super().__init__()
        self.class_weights = class_weights
        self.ignore_index = ignore_index
        self.use_top_k = use_top_k
        self.top_k_ratio = top_k_ratio
        self.future_discount = future_discount

    def forward(self, prediction, target):
        if target.shape[-3] != 1:
            raise ValueError('segmentation label must be an index-label with channel dimension = 1.')
        b, s, c, h, w = prediction.shape

        prediction = prediction.view(b * s, c, h, w)
        target = target.view(b * s, h, w)
        loss = F.cross_entropy(
            prediction,
            target,
            ignore_index=self.ignore_index,
            reduction='none',
            weight=self.class_weights.to(target.device),
        )

        loss = loss.view(b, s, h, w)

        future_discounts = self.future_discount ** torch.arange(s, device=loss.device, dtype=loss.dtype)
        future_discounts = future_discounts.view(1, s, 1, 1)
        loss = loss * future_discounts

        loss = loss.view(b, s, -1)
        if self.use_top_k:
            # Penalises the top-k hardest pixels
            k = int(self.top_k_ratio * loss.shape[2])
            loss, _ = torch.sort(loss, dim=2, descending=True)
            loss = loss[:, :, :k]

        return torch.mean(loss)


class ProbabilisticLoss(nn.Module):
    def forward(self, output):
        present_mu = output['present_mu']
        present_log_sigma = output['present_log_sigma']
        future_mu = output['future_mu']
        future_log_sigma = output['future_log_sigma']

        var_future = torch.exp(2 * future_log_sigma)
        var_present = torch.exp(2 * present_log_sigma)
        kl_div = (
                present_log_sigma - future_log_sigma - 0.5 + (var_future + (future_mu - present_mu) ** 2) / (
                    2 * var_present)
        )

        kl_loss = torch.mean(torch.sum(kl_div, dim=-1))

        return kl_loss

def _gather_feat(feat, ind, mask=None):
    dim  = feat.size(2)
    #print('ind type:  ',ind.dtype)
    ind  = ind.unsqueeze(2).expand(ind.size(0), ind.size(1), dim)
    #print('feat ind:  ',feat.shape , ind.shape) #[2, 40000, 2] [2, 128, 2]
    #print('ind: ',ind)
    feat = feat.gather(1, ind)
    if mask is not None:
        mask = mask.unsqueeze(2).expand_as(feat)
        feat = feat[mask]
        feat = feat.view(-1, dim)
    return feat

def _transpose_and_gather_feat(feat, ind):
    feat = feat.permute(0, 2, 3, 1).contiguous()
    feat = feat.view(feat.size(0), -1, feat.size(3))
    feat = _gather_feat(feat, ind)
    return feat

class RegL1Loss(nn.Module):
    def __init__(self):
        super(RegL1Loss, self).__init__()

    def forward(self, output, mask, ind, target):
        #print(ind)
        pred = _transpose_and_gather_feat(output, ind)
        mask = mask.unsqueeze(2).expand_as(pred).float()
        # loss = F.l1_loss(pred * mask, target * mask, reduction='elementwise_mean')
        #print('pred mask:  ', pred.shape, mask.shape)  #(4,256,2)  (4,256,2)
        #print('mask: ',mask.shape)
        #print('pred * mask: ',(pred * mask).shape)
        #print('target * mask: ',(target * mask).shape )
        
        loss = F.l1_loss(pred * mask, target * mask, size_average=False)
        #print('loss: ',loss)
        #print(mask)
        #print('after pred mask:  ', loss.shape, mask.shape)
        #torch.Size([]) torch.Size([4, 256, 2])
        loss = loss / (mask.sum() + 1e-4)
        return loss


class WHLoss(nn.Module):
    def __init__(self):
        super().__init__()
        self.regloss = RegL1Loss()
    def forward(self, prediction, target_wh, target_index, target_mask):
        #print('target_index type:  ', target_index.dtype)
        #print('before prediction:  ',prediction.shape, target_wh.shape, target_index.shape, target_mask.shape)
        #[2, 1, 2, 200, 200] [2, 1, 128, 2]  [2, 1, 128] [2, 1, 128]
        b, s, c, h, w = prediction.shape
        prediction = prediction.view(b * s, c, h, w)
        target_wh = target_wh.view(b*s, target_wh.shape[-2], target_wh.shape[-1])
        target_index = target_index.view(b*s, target_index.shape[-1])
        target_mask = target_mask.view(b*s, target_mask.shape[-1])
        #print('after prediction:  ',prediction.shape,target_wh.shape,target_index.shape,target_mask.shape)
        # ([2, 2, 200, 200]) ([2, 128, 2]) ([2, 128]) ([2, 128])
        ##[1, 2, 256, 384]  [1, 128]  [1, 128] [1, 128, 2]
        loss = self.regloss(prediction, target_mask, target_index, target_wh)
        #print('loss--------',loss)
        return loss

    

class BinRotLoss(nn.Module):
    def __init__(self):
        super(BinRotLoss, self).__init__()

    def forward(self, output, mask, ind, rotbin, rotres):
        # [2, 1, 8, 200, 200] [2, 1, 128] [2, 1, 128] [2, 1, 128, 2] [2, 1, 128, 2]
        b, s, c, h, w = output.shape
        output = output.view(b*s,c,h,w)
        mask = mask.view(b*s,mask.shape[-1])
        ind = ind.view(b*s,ind.shape[-1])
        rotbin = rotbin.view(b*s,rotbin.shape[-2],rotbin.shape[-1])
        rotres = rotres.view(b*s,rotres.shape[-2],rotres.shape[-1])

        pred = _transpose_and_gather_feat(output, ind)
        loss = compute_rot_loss(pred, rotbin, rotres, mask)
        return loss

# TODO: weight
def compute_bin_loss(output, target, mask):
    #print('output: ',output)
    #print('target: ',target)
    mask = mask.view(-1,1)
    #print('---------output, target, mask:  ',output.shape, target.shape, mask.shape)
    mask = mask.expand_as(output)
    output = output * mask.float()
    #return F.cross_entropy(output, target, reduction='elementwise_mean')
    return F.cross_entropy(output, target, reduction='mean')

def compute_res_loss(output, target):
    return F.smooth_l1_loss(output, target, reduction='elementwise_mean')

def compute_rot_loss(output, target_bin, target_res, mask):
    # output: (B, 128, 8) [bin1_cls[0], bin1_cls[1], bin1_sin, bin1_cos,
    #                      bin2_cls[0], bin2_cls[1], bin2_sin, bin2_cos]
    # target_bin: (B, 128, 2) [bin1_cls, bin2_cls]
    # target_res: (B, 128, 2) [bin1_res, bin2_res]
    # mask: (B, 128, 1)
    # import pdb; pdb.set_trace()
    output = output.view(-1, 8)
    target_bin = target_bin.view(-1, 2)
    target_res = target_res.view(-1, 2)
    mask = mask.view(-1, 1)
    loss_bin1 = compute_bin_loss(output[:, 0:2], target_bin[:, 0], mask)
    loss_bin2 = compute_bin_loss(output[:, 4:6], target_bin[:, 1], mask)
    loss_res = torch.zeros_like(loss_bin1)
    if target_bin[:, 0].nonzero().shape[0] > 0:
        idx1 = target_bin[:, 0].nonzero()[:, 0]
        valid_output1 = torch.index_select(output, 0, idx1.long())
        valid_target_res1 = torch.index_select(target_res, 0, idx1.long())
        loss_sin1 = compute_res_loss(
          valid_output1[:, 2], torch.sin(valid_target_res1[:, 0]))
        loss_cos1 = compute_res_loss(
          valid_output1[:, 3], torch.cos(valid_target_res1[:, 0]))
        loss_res += loss_sin1 + loss_cos1
    if target_bin[:, 1].nonzero().shape[0] > 0:
        idx2 = target_bin[:, 1].nonzero()[:, 0]
        valid_output2 = torch.index_select(output, 0, idx2.long())
        valid_target_res2 = torch.index_select(target_res, 0, idx2.long())
        loss_sin2 = compute_res_loss(
          valid_output2[:, 6], torch.sin(valid_target_res2[:, 1]))
        loss_cos2 = compute_res_loss(
          valid_output2[:, 7], torch.cos(valid_target_res2[:, 1]))
        loss_res += loss_sin2 + loss_cos2
    return loss_bin1 + loss_bin2 + loss_res


def _neg_loss(pred, gt):
  ''' Modified focal loss. Exactly the same as CornerNet.
      Runs faster and costs a little bit more memory
    Arguments:
      pred (batch x c x h x w)
      gt_regr (batch x c x h x w)
  '''
  pos_inds = gt.eq(1).float()
  neg_inds = gt.lt(1).float()

  neg_weights = torch.pow(1 - gt, 4)

  loss = 0

  pos_loss = torch.log(pred) * torch.pow(1 - pred, 2) * pos_inds
  neg_loss = torch.log(1 - pred) * torch.pow(pred, 2) * neg_weights * neg_inds

  num_pos  = pos_inds.float().sum()
  pos_loss = pos_loss.sum()
  neg_loss = neg_loss.sum()

  if num_pos == 0:
    loss = loss - neg_loss
  else:
    loss = loss - (pos_loss + neg_loss) / num_pos
  return loss


class FocalLoss(nn.Module):
  '''nn.Module warpper for focal loss'''
  def __init__(self):
    super(FocalLoss, self).__init__()
    self.neg_loss = _neg_loss

  def forward(self, out, target):
    b, s, c, h, w = out.shape
    out = out.view(b * s, c, h, w)

    b, s, c, h, w = target.shape
    target = target.view(b * s, c, h, w)

    return self.neg_loss(out, target)