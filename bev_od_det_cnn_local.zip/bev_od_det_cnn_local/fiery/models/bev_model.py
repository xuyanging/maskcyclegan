from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch
import torch.nn as nn

import os
import sys
'''
root_path = os.path.abspath(__file__)
print(root_path)
sys.path.append(root_path)
root_path = '/'.join(root_path.split('/')[:-3])
print(root_path)
sys.path.append(root_path)
'''

#import sys
#sys.path.append("..")
#from encoder import Encoder
from fiery.models.encoder import Encoder
#from fiery.models.temporal_model import TemporalModelIdentity, TemporalModel
#from fiery.models.distributions import DistributionModule
#from fiery.models.future_prediction import FuturePrediction
from fiery.models.decoder import Decoder
from fiery.utils.network import pack_sequence_dim, unpack_sequence_dim, set_bn_momentum
from fiery.utils.geometry import cumulative_warp_features, calculate_birds_eye_view_parameters, VoxelsSumming
import numpy as np

class Fiery(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg

        bev_resolution, bev_start_position, bev_dimension = calculate_birds_eye_view_parameters(
            self.cfg.LIFT.X_BOUND, self.cfg.LIFT.Y_BOUND, self.cfg.LIFT.Z_BOUND
        )
        #print('bev_resolution, bev_start_position, bev_dimension:',bev_resolution, bev_start_position, bev_dimension)
        #[ 0.5000,  0.5000, 20.0000] [-49.7500, -49.7500,   0.0000]  [200, 200,   1]
        self.bev_resolution = nn.Parameter(bev_resolution, requires_grad=False)
        self.bev_start_position = nn.Parameter(bev_start_position, requires_grad=False)
        self.bev_dimension = nn.Parameter(bev_dimension, requires_grad=False)

        self.encoder_downsample = self.cfg.MODEL.ENCODER.DOWNSAMPLE  #8
        self.encoder_out_channels = self.cfg.MODEL.ENCODER.OUT_CHANNELS  #64

        self.frustum = self.create_frustum()
        self.depth_channels, _, _, _ = self.frustum.shape  #48

        #print('-----------TIME_RECEPTIVE_FIELD: ',self.cfg.TIME_RECEPTIVE_FIELD)
        self.receptive_field = self.cfg.TIME_RECEPTIVE_FIELD
        #self.receptive_field=1
        '''
        if self.cfg.TIME_RECEPTIVE_FIELD == 1:
            assert self.cfg.MODEL.TEMPORAL_MODEL.NAME == 'identity'

        # temporal block
        self.receptive_field = self.cfg.TIME_RECEPTIVE_FIELD
        self.n_future = self.cfg.N_FUTURE_FRAMES
        self.latent_dim = self.cfg.MODEL.DISTRIBUTION.LATENT_DIM
        '''

        '''
        if self.cfg.MODEL.SUBSAMPLE:
            assert self.cfg.DATASET.NAME == 'lyft'
            self.receptive_field = 3
            self.n_future = 5
        '''

        # Spatial extent in bird's-eye view, in meters
        self.spatial_extent = (self.cfg.LIFT.X_BOUND[1], self.cfg.LIFT.Y_BOUND[1])
        self.bev_size = (self.bev_dimension[0].item(), self.bev_dimension[1].item())

        # Encoder
        self.encoder = Encoder(cfg=self.cfg.MODEL.ENCODER, D=self.depth_channels)
        self.coord_map = self.create_coord_map(self.bev_dimension[0].item(), self.bev_dimension[1].item())
        #print('coord_map:  ',self.coord_map.shape)  # [1, 2, 200, 200]
        '''
        # Temporal model
        temporal_in_channels = self.encoder_out_channels
        if self.cfg.MODEL.TEMPORAL_MODEL.INPUT_EGOPOSE:
            temporal_in_channels += 6
        if self.cfg.MODEL.TEMPORAL_MODEL.NAME == 'identity':
            self.temporal_model = TemporalModelIdentity(temporal_in_channels, self.receptive_field)
        elif cfg.MODEL.TEMPORAL_MODEL.NAME == 'temporal_block':
            self.temporal_model = TemporalModel(
                temporal_in_channels,
                self.receptive_field,
                input_shape=self.bev_size,
                start_out_channels=self.cfg.MODEL.TEMPORAL_MODEL.START_OUT_CHANNELS,
                extra_in_channels=self.cfg.MODEL.TEMPORAL_MODEL.EXTRA_IN_CHANNELS,
                n_spatial_layers_between_temporal_layers=self.cfg.MODEL.TEMPORAL_MODEL.INBETWEEN_LAYERS,
                use_pyramid_pooling=self.cfg.MODEL.TEMPORAL_MODEL.PYRAMID_POOLING,
            )
        else:
            raise NotImplementedError(f'Temporal module {self.cfg.MODEL.TEMPORAL_MODEL.NAME}.')
        '''

        '''
        self.future_pred_in_channels = self.temporal_model.out_channels
        if self.n_future > 0:
            # probabilistic sampling
            if self.cfg.PROBABILISTIC.ENABLED:
                # Distribution networks
                self.present_distribution = DistributionModule(
                    self.future_pred_in_channels,
                    self.latent_dim,
                    min_log_sigma=self.cfg.MODEL.DISTRIBUTION.MIN_LOG_SIGMA,
                    max_log_sigma=self.cfg.MODEL.DISTRIBUTION.MAX_LOG_SIGMA,
                )

                future_distribution_in_channels = (self.future_pred_in_channels
                                                   + self.n_future * self.cfg.PROBABILISTIC.FUTURE_DIM
                                                   )
                self.future_distribution = DistributionModule(
                    future_distribution_in_channels,
                    self.latent_dim,
                    min_log_sigma=self.cfg.MODEL.DISTRIBUTION.MIN_LOG_SIGMA,
                    max_log_sigma=self.cfg.MODEL.DISTRIBUTION.MAX_LOG_SIGMA,
                )

            # Future prediction
            self.future_prediction = FuturePrediction(
                in_channels=self.future_pred_in_channels,
                latent_dim=self.latent_dim,
                n_gru_blocks=self.cfg.MODEL.FUTURE_PRED.N_GRU_BLOCKS,
                n_res_layers=self.cfg.MODEL.FUTURE_PRED.N_RES_LAYERS,
            )
        '''

        # Decoder
        self.decoder = Decoder(
            #in_channels=self.future_pred_in_channels,
            in_channels=64+2,
            n_classes=len(self.cfg.SEMANTIC_SEG.WEIGHTS),
            predict_future_flow=self.cfg.INSTANCE_FLOW.ENABLED,
        )

        set_bn_momentum(self, self.cfg.MODEL.BN_MOMENTUM)

    def create_frustum(self):
        # Create grid in image plane
        h, w = self.cfg.IMAGE.FINAL_DIM  #(224, 480)
        downsampled_h, downsampled_w = h // self.encoder_downsample, w // self.encoder_downsample
        #print('downsampled_h, downsampled_w: ',downsampled_h, downsampled_w)  #28 60
        # Depth grid
        depth_grid = torch.arange(*self.cfg.LIFT.D_BOUND, dtype=torch.float)  # [2.0, 50.0, 1.0]
        #print('depth_grid: ',depth_grid.shape) #[48]
        depth_grid = depth_grid.view(-1, 1, 1).expand(-1, downsampled_h, downsampled_w)  # [48 ,28 ,60]
        n_depth_slices = depth_grid.shape[0]  # 48
        #[2., 3., 4., 5., 6., 7., 8., 9., 10., 11., 12., 13., 14., 15.,
        # 16., 17., 18., 19., 20., 21., 22., 23., 24., 25., 26., 27., 28., 29.,
        # 30., 31., 32., 33., 34., 35., 36., 37., 38., 39., 40., 41., 42., 43.,
        # 44., 45., 46., 47., 48., 49.]

        # x and y grids
        #(0,479,60)
        x_grid = torch.linspace(0, w - 1, downsampled_w, dtype=torch.float) #[0.0000,8.1186,16.2373,24.3559,32.4746,...,479]
        #print('x_grid: ', x_grid)
        #[0.0000, 8.1186, 16.2373, 24.3559, 32.4746, 40.5932, 48.7119,...
        # 454.6441, 462.7627, 470.8813, 479.0000]
        x_grid = x_grid.view(1, 1, downsampled_w).expand(n_depth_slices, downsampled_h, downsampled_w) # [48 ,28 ,60]

        #(0,223,28)
        y_grid = torch.linspace(0, h - 1, downsampled_h, dtype=torch.float)
        #print('y_grid: ', y_grid)
        #[0.0000, 8.2593, 16.5185, 24.7778, 33.0370, 41.2963, 49.5556,...
        # 173.4444, 181.7037, 189.9630, 198.2222, 206.4815, 214.7407, 223.0000]
        y_grid = y_grid.view(1, downsampled_h, 1).expand(n_depth_slices, downsampled_h, downsampled_w) # [48 ,28 ,60]

        # Dimension (n_depth_slices, downsampled_h, downsampled_w, 3)
        # containing data points in the image: left-right, top-bottom, depth
        #print('x_grid, y_grid, depth_grid: ',x_grid.shape, y_grid.shape, depth_grid.shape)
        #[48, 28, 60]  [48, 28, 60]   [48, 28, 60]
        frustum = torch.stack((x_grid, y_grid, depth_grid), -1)
        #print('frustum: ',frustum.shape) #[48, 28, 60, 3]
        return nn.Parameter(frustum, requires_grad=False)

    #def forward(self, image, intrinsics, extrinsics, future_egomotion, future_distribution_inputs=None, noise=None):
    def forward(self, image, intrinsics, extrinsics):
        output = {}

        #print('image, intrinsics, extrinsics: ',image.shape, intrinsics.shape, extrinsics.shape)
        # torch.Size([1, 1, 6, 3, 224, 480]) torch.Size([1, 1, 6, 3, 3]) torch.Size([1, 1, 6, 4, 4])
        # Only process features from the past and present
        #print('receptive_field: ',self.receptive_field)
        image = image[:, :self.receptive_field].contiguous()
        intrinsics = intrinsics[:, :self.receptive_field].contiguous()
        extrinsics = extrinsics[:, :self.receptive_field].contiguous()
        #future_egomotion = future_egomotion[:, :self.receptive_field].contiguous()
        #print('intrinsics:  ', intrinsics[0][0][0])
        #print('extrinsics:  ', extrinsics[0][0][0])
        # Lifting features and project to bird's-eye view
        x = self.calculate_birds_eye_view_features(image, intrinsics, extrinsics)
        #print('bev shape:  ',x.shape) #[1, 1, 64, 200, 200]  [3, 1, 64, 200, 200]

        #[1, 2, 200, 200]
        #print('coord_map:  ',self.coord_map.shape)

        #coord_map = self.coord_map.unsqueeze(0)
        #coord_map = self.coord_map.cuda()  # [1, 1, 2, 200, 200]
        coord_map = self.coord_map
        coord_map = coord_map.unsqueeze(0)
        coord_map_B = x.shape[0]
        coord_map_C = x.shape[1]
        #print('coord_map_B:  ',coord_map_B)
        coord_map = coord_map.repeat([coord_map_B, coord_map_C, 1, 1, 1])
        #print('x+coordmap:  ',x.shape,coord_map.shape)
        # [3, 1, 64, 200, 200]  [3, 1, 2, 200, 200]
        x = torch.cat([x , coord_map], dim=2)
        x = self.decoder(x)

        #print(x.keys()) #'segmentation', 'instance_center', 'instance_offset', 'instance_flow'
        #print('segmentation: ',x['segmentation'].shape)        #[1, 1, 2, 200, 200]
        #print('instance_center: ', x['instance_center'].shape) #[1, 1, 1, 200, 200]
        '''
        # Warp past features to the present's reference frame
        x = cumulative_warp_features(
            x.clone(), future_egomotion,
            mode='bilinear', spatial_extent=self.spatial_extent,
        )

        if self.cfg.MODEL.TEMPORAL_MODEL.INPUT_EGOPOSE:  #true
            b, s, c = future_egomotion.shape
            h, w = x.shape[-2:]
            future_egomotions_spatial = future_egomotion.view(b, s, c, 1, 1).expand(b, s, c, h, w)
            # at time 0, no egomotion so feed zero vector
            future_egomotions_spatial = torch.cat([torch.zeros_like(future_egomotions_spatial[:, :1]),
                                                   future_egomotions_spatial[:, :(self.receptive_field-1)]], dim=1)
            x = torch.cat([x, future_egomotions_spatial], dim=-3)

        #  Temporal model
        states = self.temporal_model(x)

        if self.n_future > 0:
            # Split into present and future features (for the probabilistic model)
            present_state = states[:, :1].contiguous()
            if self.cfg.PROBABILISTIC.ENABLED:
                # Do probabilistic computation
                sample, output_distribution = self.distribution_forward(
                    present_state, future_distribution_inputs, noise
                )
                output = {**output, **output_distribution}

            # Prepare future prediction input
            b, _, _, h, w = present_state.shape
            hidden_state = present_state[:, 0]

            if self.cfg.PROBABILISTIC.ENABLED:
                future_prediction_input = sample.expand(-1, self.n_future, -1, -1, -1)
            else:
                future_prediction_input = hidden_state.new_zeros(b, self.n_future, self.latent_dim, h, w)

            # Recursively predict future states
            future_states = self.future_prediction(future_prediction_input, hidden_state)

            # Concatenate present state
            future_states = torch.cat([present_state, future_states], dim=1)

        # Predict bird's-eye view outputs
        if self.n_future > 0:
            bev_output = self.decoder(future_states)
        else:
            bev_output = self.decoder(states[:, -1:])
        output = {**output, **bev_output}
        '''
        return x

    # [1, 6, 3, 3]  [1, 6, 4, 4]
    def get_geometry(self, intrinsics, extrinsics):
        """Calculate the (x, y, z) 3D position of the features.
        """
        rotation, translation = extrinsics[..., :3, :3], extrinsics[..., :3, 3]
        #rotation [1,6,3,3], translation [1,6,3,3]
        B, N, _ = translation.shape
        # Add batch, camera dimension, and a dummy dimension at the end
        points = self.frustum.unsqueeze(0).unsqueeze(0).unsqueeze(-1)
        #print('points: ',points.shape) #([1, 1, 48, 28, 60, 3, 1])
        # Camera to ego reference frame
        #x_grid, y_grid, depth_grid
        points = torch.cat((points[:, :, :, :, :, :2] * points[:, :, :, :, :, 2:3], points[:, :, :, :, :, 2:3]), 5)
        #print('points1: ',points.shape)  #[1, 1, 48, 28, 60, 3, 1]
        combined_transformation = rotation.matmul(intrinsics)     ##1   torch.inverse(intrinsics)
        points = combined_transformation.view(B, N, 1, 1, 1, 3, 3).matmul(points).squeeze(-1)
        points += translation.view(B, N, 1, 1, 1, 3)
        #print('points2: ', points.shape)  #[1, 6, 48, 28, 60, 3]
        # The 3 dimensions in the ego reference frame are: (forward, sides, height)
        return points

    def encoder_forward(self, x):
        # batch, n_cameras, channels, height, width
        b, n, c, h, w = x.shape

        x = x.view(b * n, c, h, w)
        #print('x0', x.shape) #[6, 3, 224, 480]
        x = self.encoder(x)
        #print('x1', x.shape) #[6, 64, 48, 28, 60]
        x = x.view(b, n, *x.shape[1:])
        #print('x2',x.shape) #[1, 6, 64, 48, 28, 60]
        x = x.permute(0, 1, 3, 4, 5, 2)
        #print('x3', x.shape) #[1, 6, 48, 28, 60, 64]
        return x

    # x:[1, 6, 48, 28, 60, 64]  geometry:[1, 6, 48, 28, 60, 3]
    def projection_to_birds_eye_view(self, x, geometry):
        """ Adapted from https://github.com/nv-tlabs/lift-splat-shoot/blob/master/src/models.py#L200"""
        # batch, n_cameras, depth, height, width, channels
        batch, n, d, h, w, c = x.shape # 1 6 48 28 60  64
        output = torch.zeros( (batch, c, self.bev_dimension[0], self.bev_dimension[1]), dtype=torch.float, device=x.device )
        # 1,64,200,200
        # Number of 3D points
        N = n * d * h * w
        for b in range(batch):
            # flatten x
            x_b = x[b].reshape(N, c) #(6*48*28*60 ,64)

            # Convert positions to integer indices
            # print(bev_resolution, bev_start_position, bev_dimension)
            # [ 0.5000,  0.5000, 20.0000] [-49.7500, -49.7500,   0.0000]  [200, 200,   1]
            #print('geometry[b]: ',geometry[b].shape) #[6, 48, 28, 60, 3]
            #print('bev_start_position: ',(self.bev_start_position - self.bev_resolution / 2.0))
            # [-50., -50., -10.]
            geometry_b = ((geometry[b] - (self.bev_start_position - self.bev_resolution / 2.0)) / self.bev_resolution)
            geometry_b = geometry_b.view(N, 3).long()

            # Mask out points that are outside the considered spatial extent.
            mask = (
                    (geometry_b[:, 0] >= 0)
                    & (geometry_b[:, 0] < self.bev_dimension[0])
                    & (geometry_b[:, 1] >= 0)
                    & (geometry_b[:, 1] < self.bev_dimension[1])
                    & (geometry_b[:, 2] >= 0)
                    & (geometry_b[:, 2] < self.bev_dimension[2])
            )
            x_b = x_b[mask]
            geometry_b = geometry_b[mask]

            # Sort tensors so that those within the same voxel are consecutives.
            ranks = (
                    geometry_b[:, 0] * (self.bev_dimension[1] * self.bev_dimension[2])
                    + geometry_b[:, 1] * (self.bev_dimension[2])
                    + geometry_b[:, 2]
            )
            #ranks_indices = ranks.argsort()
            _,ranks_indices = torch.sort(ranks)
            x_b, geometry_b, ranks = x_b[ranks_indices], geometry_b[ranks_indices], ranks[ranks_indices]

            # Project to bird's-eye view by summing voxels.
            #print('x_b, geometry_b, ranks: ',x_b.shape, geometry_b.shape, ranks.shape)
            #[451607, 64]  [451607, 3]  [451607]
            
            #x_b, geometry_b = VoxelsSumming.apply(x_b, geometry_b, ranks)

            bev_feature = torch.zeros((self.bev_dimension[2], self.bev_dimension[0], self.bev_dimension[1], c),
                                      device=x_b.device)
            bev_feature[geometry_b[:, 2], geometry_b[:, 0], geometry_b[:, 1]] = x_b

            # Put channel in second position and remove z dimension
            bev_feature = bev_feature.permute((0, 3, 1, 2))
            bev_feature = bev_feature.squeeze(0)

            output[b] = bev_feature

        return output

    # [1, 1, 6, 3, 224, 480]  [1, 1, 6, 3, 3]  [1, 1, 6, 4, 4]
    def calculate_birds_eye_view_features(self, x, intrinsics, extrinsics):
        b, s, n, c, h, w = x.shape  #batch, sequen, num_camera, channel, h, w
        # Reshape
        #print('x1: ', x.shape) #[1, 1, 6, 3, 224, 480]
        x = pack_sequence_dim(x)
        #print('x2: ',x.shape)  #[1, 6, 3, 224, 480]
        #print('intrinsics before: ',intrinsics.shape)  #[1, 1, 6, 3, 3]
        #print('extrinsics before: ', extrinsics.shape) #[1, 1, 6, 4, 4]
        intrinsics = pack_sequence_dim(intrinsics)
        extrinsics = pack_sequence_dim(extrinsics)
        #print('intrinsics after: ',intrinsics.shape)  #[1, 6, 3, 3]
        #print('extrinsics after: ', extrinsics.shape) #[1, 6, 4, 4]

        geometry = self.get_geometry(intrinsics, extrinsics)
        #print('geometry: ',geometry.shape) #[1, 6, 48, 28, 60, 3]
        #print('geometry: ',geometry)
        x = self.encoder_forward(x)
        #print('x3: ', x.shape)  #[1, 6, 48, 28, 60, 64]
        x = self.projection_to_birds_eye_view(x, geometry)
        #print('x4: ', x.shape)  #[1, 64, 200, 200]
        x = unpack_sequence_dim(x, b, s) #[1, 1, 64, 200, 200]
        return x

    def distribution_forward(self, present_features, future_distribution_inputs=None, noise=None):
        """
        Parameters
        ----------
            present_features: 5-D output from dynamics module with shape (b, 1, c, h, w)
            future_distribution_inputs: 5-D tensor containing labels shape (b, s, cfg.PROB_FUTURE_DIM, h, w)
            noise: a sample from a (0, 1) gaussian with shape (b, s, latent_dim). If None, will sample in function

        Returns
        -------
            sample: sample taken from present/future distribution, broadcast to shape (b, s, latent_dim, h, w)
            present_distribution_mu: shape (b, s, latent_dim)
            present_distribution_log_sigma: shape (b, s, latent_dim)
            future_distribution_mu: shape (b, s, latent_dim)
            future_distribution_log_sigma: shape (b, s, latent_dim)
        """
        b, s, _, h, w = present_features.size()
        assert s == 1

        present_mu, present_log_sigma = self.present_distribution(present_features)

        future_mu, future_log_sigma = None, None
        if future_distribution_inputs is not None:
            # Concatenate future labels to z_t
            future_features = future_distribution_inputs[:, 1:].contiguous().view(b, 1, -1, h, w)
            future_features = torch.cat([present_features, future_features], dim=2)
            future_mu, future_log_sigma = self.future_distribution(future_features)

        if noise is None:
            if self.training:
                noise = torch.randn_like(present_mu)
            else:
                noise = torch.zeros_like(present_mu)
        if self.training:
            mu = future_mu
            sigma = torch.exp(future_log_sigma)
        else:
            mu = present_mu
            sigma = torch.exp(present_log_sigma)
        sample = mu + sigma * noise

        # Spatially broadcast sample to the dimensions of present_features
        sample = sample.view(b, s, self.latent_dim, 1, 1).expand(b, s, self.latent_dim, h, w)

        output_distribution = {
            'present_mu': present_mu,
            'present_log_sigma': present_log_sigma,
            'future_mu': future_mu,
            'future_log_sigma': future_log_sigma,
        }

        return sample, output_distribution

    #def create_coord_map(self, img_size, with_r=False):
    def create_coord_map(self, H, W, with_r=False):
        #H, W, C = img_size
        grid_x, grid_y = np.meshgrid(np.arange(W), np.arange(H))
        grid_x = torch.from_numpy(grid_x / (W - 1) * 2 - 1).float()
        grid_y = torch.from_numpy(grid_y / (H - 1) * 2 - 1).float()
        ret = torch.stack([grid_x, grid_y], dim=0).unsqueeze(0)
        if with_r:
            rr = torch.sqrt(torch.pow(grid_x, 2) + torch.pow(grid_y, 2)).view([1, 1, H, W])
            ret = torch.cat([ret, rr], dim=1)
        #ret = ret.unsqueeze(0)
        return ret

if __name__ == '__main__':
    from fiery.config import get_parser, get_cfg
    args = get_parser().parse_args()
    cfg = get_cfg(args)

    cfg = cfg.convert_to_dict()
    cfg = get_cfg(cfg_dict=cfg)
    #cfg = get_cfg(cfg.convert_to_dict())
    model = Fiery(cfg)
    input_img = torch.rand(1, 1, 6, 3, 224, 480)
    input_intrinsics = torch.rand(1 ,1 ,6 ,3 ,3)
    input_extrinsics = torch.rand(1, 1, 6,4,4)

    output=model(input_img,input_intrinsics,input_extrinsics)
    #print('output: ',output.shape)
    # print('extrinsics:  ', image.shape, intrinsics.shape, extrinsics.shape)
    # ([1, 4, 6, 3, 224, 480]) ([1, 4, 6, 3, 3]) ([1, 4, 6, 4, 4])