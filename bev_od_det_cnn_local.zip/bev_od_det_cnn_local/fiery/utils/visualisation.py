import numpy as np
import torch
import matplotlib.pylab
import cv2
import torch.nn as nn
import math
from fiery.utils.instance import predict_instance_segmentation_and_trajectories

DEFAULT_COLORMAP = matplotlib.pylab.cm.jet


def flow_to_image(flow: np.ndarray, autoscale: bool = False) -> np.ndarray:
    """
    Applies colour map to flow which should be a 2 channel image tensor HxWx2. Returns a HxWx3 numpy image
    Code adapted from: https://github.com/liruoteng/FlowNet/blob/master/models/flownet/scripts/flowlib.py
    """
    u = flow[0, :, :]
    v = flow[1, :, :]

    # Convert to polar coordinates
    rad = np.sqrt(u ** 2 + v ** 2)
    maxrad = np.max(rad)

    # Normalise flow maps
    if autoscale:
        u /= maxrad + np.finfo(float).eps
        v /= maxrad + np.finfo(float).eps

    # visualise flow with cmap
    return np.uint8(compute_color(u, v) * 255)


def _normalise(image: np.ndarray) -> np.ndarray:
    lower = np.min(image)
    delta = np.max(image) - lower
    if delta == 0:
        delta = 1
    image = (image.astype(np.float32) - lower) / delta
    return image


def apply_colour_map(
    image: np.ndarray, cmap: matplotlib.colors.LinearSegmentedColormap = DEFAULT_COLORMAP, autoscale: bool = False
) -> np.ndarray:
    """
    Applies a colour map to the given 1 or 2 channel numpy image. if 2 channel, must be 2xHxW.
    Returns a HxWx3 numpy image
    """
    if image.ndim == 2 or (image.ndim == 3 and image.shape[0] == 1):
        if image.ndim == 3:
            image = image[0]
        # grayscale scalar image
        if autoscale:
            image = _normalise(image)
        return cmap(image)[:, :, :3]
    if image.shape[0] == 2:
        # 2 dimensional UV
        return flow_to_image(image, autoscale=autoscale)
    if image.shape[0] == 3:
        # normalise rgb channels
        if autoscale:
            image = _normalise(image)
        return np.transpose(image, axes=[1, 2, 0])
    raise Exception('Image must be 1, 2 or 3 channel to convert to colour_map (CxHxW)')


def heatmap_image(
    image: np.ndarray, cmap: matplotlib.colors.LinearSegmentedColormap = DEFAULT_COLORMAP, autoscale: bool = True
) -> np.ndarray:
    """Colorize an 1 or 2 channel image with a colourmap."""
    if not issubclass(image.dtype.type, np.floating):
        raise ValueError(f"Expected a ndarray of float type, but got dtype {image.dtype}")
    if not (image.ndim == 2 or (image.ndim == 3 and image.shape[0] in [1, 2])):
        raise ValueError(f"Expected a ndarray of shape [H, W] or [1, H, W] or [2, H, W], but got shape {image.shape}")
    heatmap_np = apply_colour_map(image, cmap=cmap, autoscale=autoscale)
    heatmap_np = np.uint8(heatmap_np * 255)
    return heatmap_np

def make_heatmaps(heatmaps):
        # heatmaps = torch.from_numpy(heatmaps)
        # print(image.shape)
        heatmaps = heatmaps.mul(255) \
            .clamp(0, 255) \
            .byte() \
            .cpu().numpy()
        # print(heatmaps.shape)
        num_joints, height, width = heatmaps.shape
        # print('width height:  ',int(width), int(height))  # 224 128
        # image_resized = cv2.resize(image, (int(width), int(height)))

        image_grid = np.zeros((num_joints * height, width, 3), dtype=np.uint8)

        for j in range(num_joints):
            # add_joints(image_resized, joints[:, j, :])
            heatmap = heatmaps[j, :, :]
            colored_heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
            image_fused = colored_heatmap  # * 0.7 + image_resized * 0.3

            height_begin = height * (j + 0)
            height_end = height * (j + 1)
            image_grid[height_begin:height_end, :, :] = image_fused

        # image_grid[0:height, :, :] = image_resized

        return image_grid


def compute_color(u: np.ndarray, v: np.ndarray) -> np.ndarray:
    assert u.shape == v.shape
    [h, w] = u.shape
    img = np.zeros([h, w, 3])
    nan_mask = np.isnan(u) | np.isnan(v)
    u[nan_mask] = 0
    v[nan_mask] = 0

    colorwheel = make_color_wheel()
    ncols = np.size(colorwheel, 0)

    rad = np.sqrt(u ** 2 + v ** 2)
    a = np.arctan2(-v, -u) / np.pi
    f_k = (a + 1) / 2 * (ncols - 1) + 1
    k_0 = np.floor(f_k).astype(int)
    k_1 = k_0 + 1
    k_1[k_1 == ncols + 1] = 1
    f = f_k - k_0

    for i in range(0, np.size(colorwheel, 1)):
        tmp = colorwheel[:, i]
        col0 = tmp[k_0 - 1] / 255
        col1 = tmp[k_1 - 1] / 255
        col = (1 - f) * col0 + f * col1

        idx = rad <= 1
        col[idx] = 1 - rad[idx] * (1 - col[idx])
        notidx = np.logical_not(idx)

        col[notidx] *= 0.75
        img[:, :, i] = col * (1 - nan_mask)

    return img


def make_color_wheel() -> np.ndarray:
    """
    Create colour wheel.
    Code adapted from https://github.com/liruoteng/FlowNet/blob/master/models/flownet/scripts/flowlib.py
    """
    red_yellow = 15
    yellow_green = 6
    green_cyan = 4
    cyan_blue = 11
    blue_magenta = 13
    magenta_red = 6

    ncols = red_yellow + yellow_green + green_cyan + cyan_blue + blue_magenta + magenta_red
    colorwheel = np.zeros([ncols, 3])

    col = 0

    # red_yellow
    colorwheel[0:red_yellow, 0] = 255
    colorwheel[0:red_yellow, 1] = np.transpose(np.floor(255 * np.arange(0, red_yellow) / red_yellow))
    col += red_yellow

    # yellow_green
    colorwheel[col : col + yellow_green, 0] = 255 - np.transpose(
        np.floor(255 * np.arange(0, yellow_green) / yellow_green)
    )
    colorwheel[col : col + yellow_green, 1] = 255
    col += yellow_green

    # green_cyan
    colorwheel[col : col + green_cyan, 1] = 255
    colorwheel[col : col + green_cyan, 2] = np.transpose(np.floor(255 * np.arange(0, green_cyan) / green_cyan))
    col += green_cyan

    # cyan_blue
    colorwheel[col : col + cyan_blue, 1] = 255 - np.transpose(np.floor(255 * np.arange(0, cyan_blue) / cyan_blue))
    colorwheel[col : col + cyan_blue, 2] = 255
    col += cyan_blue

    # blue_magenta
    colorwheel[col : col + blue_magenta, 2] = 255
    colorwheel[col : col + blue_magenta, 0] = np.transpose(np.floor(255 * np.arange(0, blue_magenta) / blue_magenta))
    col += +blue_magenta

    # magenta_red
    colorwheel[col : col + magenta_red, 2] = 255 - np.transpose(np.floor(255 * np.arange(0, magenta_red) / magenta_red))
    colorwheel[col : col + magenta_red, 0] = 255

    return colorwheel


def make_contour(img, colour=[0, 0, 0], double_line=False):
    h, w = img.shape[:2]
    out = img.copy()
    # Vertical lines
    out[np.arange(h), np.repeat(0, h)] = colour
    out[np.arange(h), np.repeat(w - 1, h)] = colour

    # Horizontal lines
    out[np.repeat(0, w), np.arange(w)] = colour
    out[np.repeat(h - 1, w), np.arange(w)] = colour

    if double_line:
        out[np.arange(h), np.repeat(1, h)] = colour
        out[np.arange(h), np.repeat(w - 2, h)] = colour

        # Horizontal lines
        out[np.repeat(1, w), np.arange(w)] = colour
        out[np.repeat(h - 2, w), np.arange(w)] = colour
    return out


def plot_instance_map(instance_image, instance_map, instance_colours=None, bg_image=None):
    if isinstance(instance_image, torch.Tensor):
        instance_image = instance_image.cpu().numpy()
    assert isinstance(instance_image, np.ndarray)
    if instance_colours is None:
        instance_colours = generate_instance_colours(instance_map)
    if len(instance_image.shape) > 2:
        instance_image = instance_image.reshape((instance_image.shape[-2], instance_image.shape[-1]))

    if bg_image is None:
        plot_image = 255 * np.ones((instance_image.shape[0], instance_image.shape[1], 3), dtype=np.uint8)
    else:
        plot_image = bg_image

    for key, value in instance_colours.items():
        plot_image[instance_image == key] = value

    return plot_image


def visualise_output(labels, output, cfg):
    semantic_colours = np.array([[255, 255, 255], [0, 0, 0]], dtype=np.uint8)

    consistent_instance_seg = predict_instance_segmentation_and_trajectories(
        output, compute_matched_centers=False
    )

    sequence_length = consistent_instance_seg.shape[1]
    b = 0
    video = []
    for t in range(sequence_length):
        out_t = []
        # Ground truth
        unique_ids = torch.unique(labels['instance'][b, t]).cpu().numpy()[1:]
        instance_map = dict(zip(unique_ids, unique_ids))
        instance_plot = plot_instance_map(labels['instance'][b, t].cpu(), instance_map)[::-1, ::-1]
        instance_plot = make_contour(instance_plot)

        semantic_seg = labels['segmentation'].squeeze(2).cpu().numpy()
        semantic_plot = semantic_colours[semantic_seg[b, t][::-1, ::-1]]
        semantic_plot = make_contour(semantic_plot)

        if cfg.INSTANCE_FLOW.ENABLED:
            future_flow_plot = labels['flow'][b, t].cpu().numpy()
            future_flow_plot[:, semantic_seg[b, t] != 1] = 0
            future_flow_plot = flow_to_image(future_flow_plot)[::-1, ::-1]
            future_flow_plot = make_contour(future_flow_plot)
        else:
            future_flow_plot = np.zeros_like(semantic_plot)

        center_plot = heatmap_image(labels['centerness'][b, t, 0].cpu().numpy())[::-1, ::-1]
        center_plot = make_contour(center_plot)

        offset_plot = labels['offset'][b, t].cpu().numpy()
        offset_plot[:, semantic_seg[b, t] != 1] = 0
        offset_plot = flow_to_image(offset_plot)[::-1, ::-1]
        offset_plot = make_contour(offset_plot)

        out_t.append(np.concatenate([instance_plot, future_flow_plot,
                                     semantic_plot, center_plot, offset_plot], axis=0))

        # Predictions
        unique_ids = torch.unique(consistent_instance_seg[b, t]).cpu().numpy()[1:]
        instance_map = dict(zip(unique_ids, unique_ids))
        instance_plot = plot_instance_map(consistent_instance_seg[b, t].cpu(), instance_map)[::-1, ::-1]
        instance_plot = make_contour(instance_plot)

        semantic_seg = output['segmentation'].argmax(dim=2).detach().cpu().numpy()
        semantic_plot = semantic_colours[semantic_seg[b, t][::-1, ::-1]]
        semantic_plot = make_contour(semantic_plot)

        if cfg.INSTANCE_FLOW.ENABLED:
            future_flow_plot = output['instance_flow'][b, t].detach().cpu().numpy()
            future_flow_plot[:, semantic_seg[b, t] != 1] = 0
            future_flow_plot = flow_to_image(future_flow_plot)[::-1, ::-1]
            future_flow_plot = make_contour(future_flow_plot)
        else:
            future_flow_plot = np.zeros_like(semantic_plot)

        center_plot = heatmap_image(output['instance_center'][b, t, 0].detach().cpu().numpy())[::-1, ::-1]
        center_plot = make_contour(center_plot)

        offset_plot = output['instance_offset'][b, t].detach().cpu().numpy()
        offset_plot[:, semantic_seg[b, t] != 1] = 0
        offset_plot = flow_to_image(offset_plot)[::-1, ::-1]
        offset_plot = make_contour(offset_plot)

        out_t.append(np.concatenate([instance_plot, future_flow_plot,
                                     semantic_plot, center_plot, offset_plot], axis=0))
        out_t = np.concatenate(out_t, axis=1)
        # Shape (C, H, W)
        out_t = out_t.transpose((2, 0, 1))

        video.append(out_t)

    # Shape (B, T, C, H, W)
    video = np.stack(video)[None]
    return video


def convert_figure_numpy(figure):
    """ Convert figure to numpy image """
    figure_np = np.frombuffer(figure.canvas.tostring_rgb(), dtype=np.uint8)
    figure_np = figure_np.reshape(figure.canvas.get_width_height()[::-1] + (3,))
    return figure_np


def generate_instance_colours(instance_map):
    # Most distinct 22 colors (kelly colors from https://stackoverflow.com/questions/470690/how-to-automatically-generate
    # -n-distinct-colors)
    # plus some colours from AD40k
    INSTANCE_COLOURS = np.asarray([
        [0, 0, 0],
        [255, 179, 0],
        [128, 62, 117],
        [255, 104, 0],
        [166, 189, 215],
        [193, 0, 32],
        [206, 162, 98],
        [129, 112, 102],
        [0, 125, 52],
        [246, 118, 142],
        [0, 83, 138],
        [255, 122, 92],
        [83, 55, 122],
        [255, 142, 0],
        [179, 40, 81],
        [244, 200, 0],
        [127, 24, 13],
        [147, 170, 0],
        [89, 51, 21],
        [241, 58, 19],
        [35, 44, 22],
        [112, 224, 255],
        [70, 184, 160],
        [153, 0, 255],
        [71, 255, 0],
        [255, 0, 163],
        [255, 204, 0],
        [0, 255, 235],
        [255, 0, 235],
        [255, 0, 122],
        [255, 245, 0],
        [10, 190, 212],
        [214, 255, 0],
        [0, 204, 255],
        [20, 0, 255],
        [255, 255, 0],
        [0, 153, 255],
        [0, 255, 204],
        [41, 255, 0],
        [173, 0, 255],
        [0, 245, 255],
        [71, 0, 255],
        [0, 255, 184],
        [0, 92, 255],
        [184, 255, 0],
        [255, 214, 0],
        [25, 194, 194],
        [92, 0, 255],
        [220, 220, 220],
        [255, 9, 92],
        [112, 9, 255],
        [8, 255, 214],
        [255, 184, 6],
        [10, 255, 71],
        [255, 41, 10],
        [7, 255, 255],
        [224, 255, 8],
        [102, 8, 255],
        [255, 61, 6],
        [255, 194, 7],
        [0, 255, 20],
        [255, 8, 41],
        [255, 5, 153],
        [6, 51, 255],
        [235, 12, 255],
        [160, 150, 20],
        [0, 163, 255],
        [140, 140, 140],
        [250, 10, 15],
        [20, 255, 0],
    ])

    return {instance_id: INSTANCE_COLOURS[global_instance_id % len(INSTANCE_COLOURS)] for
            instance_id, global_instance_id in instance_map.items()
            }



def _nms(heat, kernel=3):
    pad = (kernel - 1) // 2

    hmax = nn.functional.max_pool2d(heat, (kernel, kernel), stride=1, padding=pad)
    keep = (hmax == heat).float()
    return heat * keep

def _gather_feat(feat, ind, mask=None):
    dim  = feat.size(2)
    ind  = ind.unsqueeze(2).expand(ind.size(0), ind.size(1), dim)
    feat = feat.gather(1, ind)
    if mask is not None:
        mask = mask.unsqueeze(2).expand_as(feat)
        feat = feat[mask]
        feat = feat.view(-1, dim)
    return feat

def _transpose_and_gather_feat(feat, ind):
    feat = feat.permute(0, 2, 3, 1).contiguous()
    feat = feat.view(feat.size(0), -1, feat.size(3))
    feat = _gather_feat(feat, ind)
    return feat

def _topk(scores, K=40):
    batch, cat, height, width = scores.size()

    topk_scores, topk_inds = torch.topk(scores.view(batch, cat, -1), K)

    topk_inds = topk_inds % (height * width)
    topk_ys = (topk_inds / width).int().float()
    topk_xs = (topk_inds % width).int().float()

    topk_score, topk_ind = torch.topk(topk_scores.view(batch, -1), K)
    topk_clses = (topk_ind / K).int()
    topk_inds = _gather_feat(
        topk_inds.view(batch, -1, 1), topk_ind).view(batch, K)
    topk_ys = _gather_feat(topk_ys.view(batch, -1, 1), topk_ind).view(batch, K)
    topk_xs = _gather_feat(topk_xs.view(batch, -1, 1), topk_ind).view(batch, K)

    return topk_score, topk_inds, topk_clses, topk_ys, topk_xs


def show_results_car(detections_car):
    show_img = np.zeros((200,200))
    dets=detections_car[0]
    #bboxes_car 4, scores_car 1, clses_car 1, wh_car 2, xs_car 1, ys_car 1, rot_car 8
    #     0,1,2,3,            4            5        6,7        8         9  10 11 12 13 14 15 16 17
    for det in dets:
        if det[4] > 0.3:
           #cv2.rectangle(show_img,(det[0],det[1]),(det[2],det[3]),(255,255,255),2)

           w=float(det[6])
           h=float(det[7])
           xc=int(det[8])
           yc=int(det[9])

           #angle=float(det[6])
           #theta = angle/180*3.14
           #print('angle theta',angle ,theta,xc,yc,w,h)
           bin1_cls0 = float(det[10])
           bin1_cls1 = float(det[11])
           bin1_sin = float(det[12])
           bin1_cos = float(det[13])

           bin2_cls0 = float(det[14])
           bin2_cls1 = float(det[15])
           bin2_sin = float(det[16])
           bin2_cos = float(det[17])
           #print(bin1_cls0,bin1_cls1,bin1_sin,bin1_cos,bin2_cls0,bin2_cls1,bin2_sin,bin2_cos)
           #'''
           if(bin1_cls0 < bin1_cls1):
             cos_a = bin1_sin
             sin_a = - bin1_cos
             #draw 4 lines
             #p0
             x0=h/2
             y0=w/2
             x0_new=x0*cos_a-y0*sin_a
             y0_new=x0*sin_a+y0*cos_a
             x0_new=x0_new+xc
             y0_new=yc-y0_new
             #p1
             x1=h/2
             y1=-w/2
             x1_new=x1*cos_a-y1*sin_a
             y1_new=x1*sin_a+y1*cos_a
             x1_new=x1_new+xc
             y1_new=yc-y1_new
             #p2
             x2=-h/2
             y2=-w/2
             x2_new=x2*cos_a-y2*sin_a
             y2_new=x2*sin_a+y2*cos_a
             x2_new=x2_new+xc
             y2_new=yc-y2_new
             #p3
             x3=-h/2
             y3=w/2
             x3_new=x3*cos_a-y3*sin_a
             y3_new=x3*sin_a+y3*cos_a
             x3_new=x3_new+xc
             y3_new=yc-y3_new
             #p_front
             x4=h/2
             y4=0
             x4_new=x4*cos_a-y4*sin_a
             y4_new=x4*sin_a+y4*cos_a
             x4_new=x4_new+xc
             y4_new=yc-y4_new

             cv2.line(show_img,(int(x0_new),int(y0_new)),(int(x1_new),int(y1_new)),(255,255,255),1)
             cv2.line(show_img,(int(x1_new),int(y1_new)),(int(x2_new),int(y2_new)),(255,255,255),1)
             cv2.line(show_img,(int(x2_new),int(y2_new)),(int(x3_new),int(y3_new)),(255,255,255),1)
             cv2.line(show_img,(int(x3_new),int(y3_new)),(int(x0_new),int(y0_new)),(255,255,255),1)
             cv2.circle(show_img, (int(x4_new),int(y4_new)), 1, (255, 0, 0), 1, 1)
             #cv2.putText(show_img,str(int(det[6])),(det[0],det[1]),cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)
           #'''
           if(bin2_cls0<bin2_cls1):
             cos_a = - bin2_sin
             sin_a = bin2_cos
             #draw 4 lines
             #p0
             x0=h/2
             y0=w/2
             x0_new=x0*cos_a-y0*sin_a
             y0_new=x0*sin_a+y0*cos_a
             x0_new=x0_new+xc
             y0_new=yc-y0_new
             #p1
             x1=h/2
             y1=-w/2
             x1_new=x1*cos_a-y1*sin_a
             y1_new=x1*sin_a+y1*cos_a
             x1_new=x1_new+xc
             y1_new=yc-y1_new
             #p2
             x2=-h/2
             y2=-w/2
             x2_new=x2*cos_a-y2*sin_a
             y2_new=x2*sin_a+y2*cos_a
             x2_new=x2_new+xc
             y2_new=yc-y2_new
             #p3
             x3=-h/2
             y3=w/2
             x3_new=x3*cos_a-y3*sin_a
             y3_new=x3*sin_a+y3*cos_a
             x3_new=x3_new+xc
             y3_new=yc-y3_new
             #p_front
             x4=h/2
             y4=0
             x4_new=x4*cos_a-y4*sin_a
             y4_new=x4*sin_a+y4*cos_a
             x4_new=x4_new+xc
             y4_new=yc-y4_new

             cv2.line(show_img,(int(x0_new),int(y0_new)),(int(x1_new),int(y1_new)),(255,255,255),1)
             cv2.line(show_img,(int(x1_new),int(y1_new)),(int(x2_new),int(y2_new)),(255,255,255),1)
             cv2.line(show_img,(int(x2_new),int(y2_new)),(int(x3_new),int(y3_new)),(255,255,255),1)
             cv2.line(show_img,(int(x3_new),int(y3_new)),(int(x0_new),int(y0_new)),(255,255,255),1)
             cv2.circle(show_img, (int(x4_new), int(y4_new)), 1, (255, 0, 0), 1, 1)
             #cv2.putText(show_img,str(int(det[6])),(det[0],det[1]),cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)

    return show_img

def show_results_car_angle(detections_car):
    show_img = np.zeros((200,200))
    dets=detections_car[0]
    for det in dets:
        if det[4] > 0.3:
           #print('det: ',det[:4],det[4])
           #cv2.rectangle(show_img,(det[0],det[1]),(det[2],det[3]),(255,255,255),2)
           #print(int(det[6]))
           w=float(det[7])
           h=float(det[8])
           xc=int(det[9])
           yc=int(det[10])
           angle=float(det[6])
           theta = angle/180*3.14
           #print('angle theta',angle ,theta,xc,yc,w,h)
           #p0
           x0=h/2
           y0=w/2
           x0_new=x0*math.cos(theta)-y0*math.sin(theta)
           y0_new=x0*math.sin(theta)+y0*math.cos(theta)
           x0_new=x0_new+xc
           y0_new=yc-y0_new
           #p1
           x1=h/2
           y1=-w/2
           x1_new=x1*math.cos(theta)-y1*math.sin(theta)
           y1_new=x1*math.sin(theta)+y1*math.cos(theta)
           x1_new=x1_new+xc
           y1_new=yc-y1_new
           #p2
           x2=-h/2
           y2=-w/2
           x2_new=x2*math.cos(theta)-y2*math.sin(theta)
           y2_new=x2*math.sin(theta)+y2*math.cos(theta)
           x2_new=x2_new+xc
           y2_new=yc-y2_new
           #p3
           x3=-h/2
           y3=w/2
           x3_new=x3*math.cos(theta)-y3*math.sin(theta)
           y3_new=x3*math.sin(theta)+y3*math.cos(theta)
           x3_new=x3_new+xc
           y3_new=yc-y3_new

           cv2.line(show_img,(int(x0_new),int(y0_new)),(int(x1_new),int(y1_new)),(255,255,255),1)
           cv2.line(show_img,(int(x1_new),int(y1_new)),(int(x2_new),int(y2_new)),(255,255,255),1)
           cv2.line(show_img,(int(x2_new),int(y2_new)),(int(x3_new),int(y3_new)),(255,255,255),1)
           cv2.line(show_img,(int(x3_new),int(y3_new)),(int(x0_new),int(y0_new)),(255,255,255),1)
           #cv2.putText(show_img,str(int(det[6])),(det[0],det[1]),cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)
    return show_img