import torch
from fiery.trainer import TrainingModule

model_path = 'tensorboard_logs/06十二月2021at15:06:58CST_igs_baseline/default/version_0/checkpoints/epoch=7-step=75007.ckpt'


trainer = TrainingModule.load_from_checkpoint(model_path, strict=True)
trainer.eval()
device = torch.device('cpu')
trainer.to(device)
model = trainer.model
cfg = model.cfg
'''
_, valloader = prepare_dataloaders(cfg)

for i, batch in enumerate(valloader):
    preprocess_batch(batch, device)
    image = batch['image']
    intrinsics = batch['intrinsics']
    extrinsics = batch['extrinsics']
    future_egomotion = batch['future_egomotion']

    batch_size = image.shape[0]
'''
model.to(device)
image_var = torch.rand(1,1,6,3,224,480).to(device)
intrinsics_var = torch.rand(1,1,6,3,3).to(device)
extrinsics_var = torch.rand(1,1,6,4,4).to(device)
torch.onnx.export(model, (image_var,intrinsics_var,extrinsics_var), 'epoch7-step75007.onnx', opset_version=11, verbose=True, export_params=True, do_constant_folding=True)