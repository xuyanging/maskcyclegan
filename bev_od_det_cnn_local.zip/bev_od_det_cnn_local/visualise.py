import os
from argparse import ArgumentParser
from glob import glob

import cv2
import numpy as np
import torch
import torchvision
import matplotlib as mpl
import matplotlib.pyplot as plt
from PIL import Image

from fiery.trainer import TrainingModule
from fiery.utils.network import NormalizeInverse
from fiery.utils.instance import predict_instance_segmentation_and_trajectories
from fiery.utils.visualisation import plot_instance_map, generate_instance_colours, make_contour, convert_figure_numpy
from fiery.utils.visualisation import make_heatmaps, _nms, _gather_feat, _transpose_and_gather_feat, _topk, show_results_car
from fiery.data import FuturePredictionDataset
from fiery.config import get_parser, get_cfg

from tqdm import tqdm
from nuscenes.nuscenes import NuScenes
from nuscenes.utils import splits
from pyquaternion.quaternion import Quaternion

#from pyquaternion import Quaternion
from nuscenes.utils.splits import create_splits_scenes
from nuscenes.utils.data_classes import Box
from glob import glob

#EXAMPLE_DATA_PATH = 'example_data'
EXAMPLE_DATA_PATH = './example_data'


def plot_prediction(image, output, cfg, is_show=True):
    # Process predictions
    consistent_instance_seg, matched_centers = predict_instance_segmentation_and_trajectories(
        output, compute_matched_centers=True
    )

    # Plot future trajectories
    unique_ids = torch.unique(consistent_instance_seg[0, 0]).cpu().long().numpy()[1:]
    instance_map = dict(zip(unique_ids, unique_ids))
    instance_colours = generate_instance_colours(instance_map)
    vis_image = plot_instance_map(consistent_instance_seg[0, 0].cpu().numpy(), instance_map)
    trajectory_img = np.zeros(vis_image.shape, dtype=np.uint8)
    for instance_id in unique_ids:
        path = matched_centers[instance_id]
        for t in range(len(path) - 1):
            color = instance_colours[instance_id].tolist()
            cv2.line(trajectory_img, tuple(path[t]), tuple(path[t + 1]),
                     color, 4)

    # Overlay arrows
    temp_img = cv2.addWeighted(vis_image, 0.7, trajectory_img, 0.3, 1.0)
    mask = ~ np.all(trajectory_img == 0, axis=2)
    vis_image[mask] = temp_img[mask]

    # Plot present RGB frames and predictions
    val_w = 2.99
    cameras = cfg.IMAGE.NAMES
    image_ratio = cfg.IMAGE.FINAL_DIM[0] / cfg.IMAGE.FINAL_DIM[1]
    val_h = val_w * image_ratio
    fig = plt.figure(figsize=(4 * val_w, 2 * val_h))
    width_ratios = (val_w, val_w, val_w, val_w)
    gs = mpl.gridspec.GridSpec(2, 4, width_ratios=width_ratios)
    gs.update(wspace=0.0, hspace=0.0, left=0.0, right=1.0, top=1.0, bottom=0.0)

    denormalise_img = torchvision.transforms.Compose(
        (NormalizeInverse(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
         torchvision.transforms.ToPILImage(),)
    )
    for imgi, img in enumerate(image[0, -1]):
        ax = plt.subplot(gs[imgi // 3, imgi % 3])
        showimg = denormalise_img(img.cpu())
        if imgi > 2:
            showimg = showimg.transpose(Image.FLIP_LEFT_RIGHT)

        plt.annotate(cameras[imgi].replace('_', ' ').replace('CAM ', ''), (0.01, 0.87), c='white',
                     xycoords='axes fraction', fontsize=14)

        plt.imshow(showimg)
        plt.axis('off')

    ax = plt.subplot(gs[:, 3])
    plt.imshow(make_contour(vis_image[::-1, ::-1]))
    plt.axis('off')

    #plt.draw()
    #plt.show()
    plt.pause(0.001)
    figure_numpy = convert_figure_numpy(fig)
    plt.close()
    return figure_numpy

# [6, 3, 224, 480] [1,200,200] []
def save_result(images, img_grid_seg, show_bev_img, img_grid_hm, img_grid_oc, cam_name,cfg):
    val_w = 2.99
    #cameras = cfg.IMAGE.NAMES
    image_ratio = cfg.IMAGE.FINAL_DIM[0] / cfg.IMAGE.FINAL_DIM[1]
    val_h = val_w * image_ratio
    fig = plt.figure(figsize=(7 * val_w, 2 * val_h))
    width_ratios = (val_w, val_w, val_w, val_w, val_w, val_w, val_w)
    gs = mpl.gridspec.GridSpec(2, 7, width_ratios=width_ratios)
    gs.update(wspace=0.0, hspace=0.0, left=0.0, right=1.0, top=1.0, bottom=0.0)

    denormalise_img = torchvision.transforms.Compose(
        (NormalizeInverse(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
         torchvision.transforms.ToPILImage(),)
    )
    for imgi, img in enumerate(images[0, -1]):
        #print(imgi,img.shape)
        ax = plt.subplot(gs[imgi // 3, imgi % 3])
        showimg = denormalise_img(img.cpu())
        if imgi > 2:
            showimg = showimg.transpose(Image.FLIP_LEFT_RIGHT)

        plt.imshow(showimg)
        plt.axis('off')

    ax = plt.subplot(gs[:, 3])
    plt.annotate('gt_box', (0.01, 0.87), c='white',
                 xycoords='axes fraction', fontsize=14)
    plt.imshow(img_grid_seg)
    plt.axis('off')

    ax = plt.subplot(gs[:, 4])
    plt.annotate('pre_box', (0.01, 0.87), c='white',
                 xycoords='axes fraction', fontsize=14)
    plt.imshow(show_bev_img)
    plt.axis('off')

    ax = plt.subplot(gs[:, 5])
    plt.annotate('gt_hm', (0.01, 0.87), c='white',
                 xycoords='axes fraction', fontsize=14)
    plt.imshow(img_grid_hm)
    plt.axis('off')

    ax = plt.subplot(gs[:, 6])
    plt.annotate('pre_hm', (0.01, 0.87), c='white',
                 xycoords='axes fraction', fontsize=14)
    plt.imshow(img_grid_oc)
    plt.axis('off')

    #plt.show()
    #plt.pause(0.001)
    #figure_numpy = convert_figure_numpy(fig)

    output_filename = os.path.join('./output_vis', cam_name.split('/')[-1].split('.')[0]) + '.png'
    plt.savefig(output_filename, bbox_inches='tight')

    plt.close()
    #return figure_numpy


def download_example_data():
    from requests import get

    def download(url, file_name):
        # open in binary mode
        with open(file_name, "wb") as file:
            # get request
            response = get(url)
            # write to file
            file.write(response.content)

    os.makedirs(EXAMPLE_DATA_PATH, exist_ok=True)
    url_list = ['https://github.com/wayveai/fiery/releases/download/v1.0/example_1.npz',
                'https://github.com/wayveai/fiery/releases/download/v1.0/example_2.npz',
                'https://github.com/wayveai/fiery/releases/download/v1.0/example_3.npz',
                'https://github.com/wayveai/fiery/releases/download/v1.0/example_4.npz'
                ]
    for url in url_list:
        download(url, os.path.join(EXAMPLE_DATA_PATH, os.path.basename(url)))


def visualise(checkpoint_path):
    #trainer = TrainingModule.load_from_checkpoint(checkpoint_path, strict=True)
    trainer = TrainingModule.load_from_checkpoint(checkpoint_path, strict=False)
    device = torch.device('cuda:0')
    trainer = trainer.to(device)
    trainer.eval()

    # Download example data
    #download_example_data()
    # Load data
    #for data_path in sorted(glob(os.path.join(EXAMPLE_DATA_PATH, '*.png'))):
    #    pass
    #'''
    for data_path in sorted(glob(os.path.join(EXAMPLE_DATA_PATH, '*.npz'))):
        data = np.load(data_path)
        image = torch.from_numpy(data['image']).to(device)
        intrinsics = torch.from_numpy(data['intrinsics']).to(device)
        extrinsics = torch.from_numpy(data['extrinsics']).to(device)
        #future_egomotions = torch.from_numpy(data['future_egomotion']).to(device)
        print('image intrinsics extrinsics: ',image.shape,intrinsics.shape,extrinsics.shape)
        #torch.Size([1, 3, 6, 3, 224, 480]) torch.Size([1, 3, 6, 3, 3]) torch.Size([1, 3, 6, 4, 4])
        image=image[:,:1,:,:,:,:]
        intrinsics=intrinsics[:,:1,:,:,:]
        extrinsics=extrinsics[:,:1,:,:,:]
        print('image intrinsics extrinsics: ', image.shape, intrinsics.shape, extrinsics.shape)
        print('intrinsics: ',intrinsics)
        print('extrinsics: ',extrinsics)
        # Forward pass
        with torch.no_grad():
            #output = trainer.model(image, intrinsics, extrinsics, future_egomotions)
            output = trainer.model(image, intrinsics, extrinsics)

        figure_numpy = plot_prediction(image, output, trainer.cfg)
        os.makedirs('./output_vis', exist_ok=True)
        output_filename = os.path.join('./output_vis', os.path.basename(data_path).split('.')[0]) + '.png'
        Image.fromarray(figure_numpy).save(output_filename)
        print(f'Saved output in {output_filename}')
    #'''

def camera_tr(camera_id,nusc,rec):
    camera_sample = nusc.get('sample_data', rec['data'][camera_id])
    sensor_sample = nusc.get('calibrated_sensor', camera_sample['calibrated_sensor_token'])
    intrinsic = torch.Tensor(sensor_sample['camera_intrinsic'])
    # print(rec['data'][cam] , intrinsic)
    sensor_rotation = Quaternion(sensor_sample['rotation'])
    sensor_translation = np.array(sensor_sample['translation'])[:, None]
    car_egopose_to_sensor = np.vstack([
        np.hstack((sensor_rotation.rotation_matrix, sensor_translation)),
        np.array([0, 0, 0, 1])
    ])
    car_egopose_to_sensor = np.linalg.inv(car_egopose_to_sensor)
    return intrinsic,car_egopose_to_sensor

def visualise_nuscence(checkpoint_path):
    #trainer = TrainingModule.load_from_checkpoint(checkpoint_path, strict=True)
    trainer = TrainingModule.load_from_checkpoint(checkpoint_path, strict=False)
    device = torch.device('cuda:0')
    trainer = trainer.to(device)
    trainer.eval()

    cameras=['CAM_FRONT_LEFT', 'CAM_FRONT', 'CAM_FRONT_RIGHT', 'CAM_BACK_LEFT', 'CAM_BACK', 'CAM_BACK_RIGHT']
    version = 'v1.0-mini'
    dataroot = '/home/igs/datasets/nuscenes/v1.0-mini'
    nusc = NuScenes(version=version, dataroot=dataroot, verbose=True)
    split = {
            'v1.0-trainval': {True: 'train', False: 'val'},
            'v1.0-mini': {True: 'mini_train', False: 'mini_val'},
        }[nusc.version][False]
    #print('create: ',create_splits_scenes().keys()) #['train', 'val', 'test', 'mini_train', 'mini_val', 'train_detect', 'train_track']
    scenes = create_splits_scenes()[split]
    samples = [samp for samp in nusc.sample]
    samples = [samp for samp in samples if
      nusc.get('scene', samp['scene_token'])['name'] in scenes]
    samples.sort(key=lambda x: (x['scene_token'], x['timestamp']))

    args = get_parser().parse_args()
    cfg = get_cfg(args)
    val_process = FuturePredictionDataset(nusc, False, cfg)

    for sample in samples:
      rec = sample
      #image
      image, intrinsic, extrinsic = val_process.get_input_data(rec)
      #print('image shape',image.shape)  #[1, 6, 3, 224, 480]

      images, intrinsics, extrinsics=[] ,[] ,[]
      images = image.unsqueeze(0)
      intrinsics = intrinsic.unsqueeze(0)
      extrinsics = extrinsic.unsqueeze(0)
      images = images.to(device)
      intrinsics = intrinsics.to(device)
      extrinsics = extrinsics.to(device)
      #print('images, intrinsics, extrinsics:  ',images.shape, intrinsics.shape, extrinsics.shape)
      #images, intrinsics, extrinsics: [1, 1, 6, 3, 224, 480]  [1, 1, 6, 3, 3]  [1, 1, 6, 4, 4]
      cam_front_left = os.path.join(dataroot, nusc.get('sample_data', rec['data']['CAM_FRONT_LEFT'])['filename'])
      cam_front_left_name = cam_front_left.split('/')[-1]
      #print(cam_front_left_name)
      #lidar
      instance_map={}
      segmentation, instance, z_position, instance_map, attribute_label, car_label, show_img = val_process.get_birds_eye_view_label(rec,instance_map)
      #cv2.imshow('draw_gt',show_img)
      #cv2.waitKey()

      #print('segmentation hm_car:  ',segmentation.shape, car_label['hm_car'].shape)
      #segmentation hm_car: (200, 200)(1, 200, 200)
      #'''
      img_grid_seg = make_heatmaps(torch.from_numpy(segmentation).unsqueeze(0))
      img_grid_seg = cv2.flip(img_grid_seg,-1)
      #print(img_grid.shape)
      cv2.circle(img_grid_seg,( int(img_grid_seg.shape[0]/2),int(img_grid_seg.shape[1]/2) ),3,(255,255,255))
      #cv2.imshow('segmentation', img_grid_seg)
      #cv2.waitKey()

      img_grid_hm = make_heatmaps(torch.from_numpy(car_label['hm_car']))
      img_grid_hm = cv2.flip(img_grid_hm, -1)
      cv2.circle(img_grid_hm,( int(img_grid_hm.shape[0]/2),int(img_grid_hm.shape[1]/2) ),3,(255,255,255))
      #cv2.imshow('hm_car', img_grid_hm)
      #cv2.waitKey()
      #'''

      #'''
      # Forward pass
      with torch.no_grad():
        #([1, 1, 6, 3, 224, 480]) ([1, 1, 6, 3, 3]) ([1, 1, 6, 4, 4])
        output = trainer.model(images, intrinsics, extrinsics)
        #['segmentation', 'instance_center', 'instance_offset', 'instance_flow', 'object_center', 'object_wh', 'object_angle']
        #print('center wh angle:  ',output['object_center'].shape, output['object_wh'].shape, output['object_angle'].shape)
        #[1, 1, 1, 200, 200]  [1, 1, 2, 200, 200] [1, 1, 1, 200, 200]
        #print(output['segmentation'].shape, output['instance_center'].shape, output['instance_offset'].shape, output['instance_flow'].shape)
        #'''
        img_grid_oc = make_heatmaps(output['object_center'][0][0])
        img_grid_oc = cv2.flip(img_grid_oc, -1)
        cv2.circle(img_grid_oc, (int(img_grid_oc.shape[0] / 2), int(img_grid_oc.shape[1] / 2)), 3, (255, 255, 255))
        #cv2.imshow('object_center',img_grid_oc)
        #cv2.waitKey()

        img_grid_inc = make_heatmaps(output['instance_center'][0][0])
        img_grid_inc = cv2.flip(img_grid_inc, -1)
        cv2.circle(img_grid_inc, (int(img_grid_inc.shape[0] / 2), int(img_grid_inc.shape[1] / 2)), 3, (255, 255, 255))
        #cv2.imshow('instance_center',img_grid_inc)
        #cv2.waitKey()
        #'''
        batch, cat, height, width = output['object_center'][0].size()
        heat_car = _nms(output['object_center'][0])
        K=100
        scores_car, inds_car, clses_car, ys_car, xs_car = _topk(heat_car, K=K)

        xs_car = xs_car.view(batch, K, 1)
        ys_car = ys_car.view(batch, K, 1)
        clses_car = clses_car.view(batch, K, 1).float()
        scores_car = scores_car.view(batch, K, 1)

        wh_car = _transpose_and_gather_feat(output['object_wh'][0], inds_car)
        wh_car = wh_car.view(batch, K, 2)

        bboxes_car = torch.cat([xs_car - wh_car[..., 0:1] / 2, ys_car - wh_car[..., 1:2] / 2,
                                xs_car + wh_car[..., 0:1] / 2, ys_car + wh_car[..., 1:2] / 2], dim=2)

        rot_car = _transpose_and_gather_feat(output['object_angle'][0], inds_car)
        rot_car = rot_car.view(batch, K, 8)
        #'''
        #angle_car = _transpose_and_gather_feat(output['object_angle'][0], inds_car)
        #angle_car = angle_car.view(batch, K, 1)
        #print('bboxes_car, scores_car, clses_car, angle_car: ',bboxes_car.shape, scores_car.shape, clses_car.shape, angle_car.shape)
        #[1, 100, 4] [1, 100, 1] [1, 100, 1] [1, 100, 1]
        #detections_car = torch.cat([bboxes_car, scores_car, clses_car, angle_car, wh_car,xs_car,ys_car], dim=2)  #4+1+1+1+2
        detections_car = torch.cat([bboxes_car, scores_car, clses_car, wh_car, xs_car, ys_car, rot_car], dim=2)
        #print('det sep: ',bboxes_car.shape, scores_car.shape, clses_car.shape, rot_car.shape, wh_car.shape,xs_car.shape,ys_car.shape)
        #[1, 100, 4] [1, 100, 1] [1, 100, 1] [1, 100, 8] [1, 100, 2] [1, 100, 1] [1, 100, 1]
        # 4 1 1 8 2 1 1
        #print('detections_car: ',detections_car.shape) #[1, 100, 6]
        show_bev_img = show_results_car(detections_car)
        show_bev_img = cv2.flip(show_bev_img, -1)
        cv2.circle(show_bev_img, (int(show_bev_img.shape[0] / 2), int(show_bev_img.shape[1] / 2)), 3, (255, 255, 255))
        #cv2.imshow('bevimg',show_bev_img)
        #cv2.waitKey()
        #print('----------------------------')
        #'''

        save_result(images, img_grid_seg, show_bev_img, img_grid_hm, img_grid_oc, cam_front_left, trainer.cfg)
        '''
        figure_numpy = plot_prediction(images, output, trainer.cfg,False)
        os.makedirs('./output_vis', exist_ok=True)
        #output_filename = os.path.join('./output_vis', os.path.basename(data_path).split('.')[0]) + '.png'
        output_filename = os.path.join('./output_vis', cam_front_left.split('/')[-1].split('.')[0]) + '.png'
        Image.fromarray(figure_numpy).save(output_filename)
        print(f'Saved output in {output_filename}')
        '''
      #'''


      '''
      #prepare image
      cam_front_left = os.path.join(dataroot,nusc.get('sample_data', rec['data']['CAM_FRONT_LEFT'])['filename'])
      cam_front = os.path.join(dataroot,nusc.get('sample_data', rec['data']['CAM_FRONT'])['filename'])
      cam_front_right = os.path.join(dataroot,nusc.get('sample_data', rec['data']['CAM_FRONT_RIGHT'])['filename'])
      cam_back_left = os.path.join(dataroot,nusc.get('sample_data', rec['data']['CAM_BACK_LEFT'])['filename'])
      cam_back = os.path.join(dataroot,nusc.get('sample_data', rec['data']['CAM_BACK'])['filename'])
      cam_back_right = os.path.join(dataroot,nusc.get('sample_data', rec['data']['CAM_BACK_RIGHT'])['filename'])

      fl_img = cv2.imread(cam_front_left)
      f_img = cv2.imread(cam_front)
      fr_img = cv2.imread(cam_front_right)
      bl_img = cv2.imread(cam_back_left)
      b_img = cv2.imread(cam_back)
      br_img = cv2.imread(cam_back_right)

      intrinsic, car_egopose_to_sensor = camera_tr('CAM_FRONT_LEFT',nusc,rec)
      intrinsic, car_egopose_to_sensor = camera_tr('CAM_FRONT', nusc, rec)
      intrinsic, car_egopose_to_sensor = camera_tr('CAM_FRONT_RIGHT', nusc, rec)
      intrinsic, car_egopose_to_sensor = camera_tr('CAM_BACK_LEFT', nusc, rec)
      intrinsic, car_egopose_to_sensor = camera_tr('CAM_BACK', nusc, rec)
      intrinsic, car_egopose_to_sensor = camera_tr('CAM_BACK_RIGHT', nusc, rec)
      print('intrinsic, car_egopose_to_sensor:  ',intrinsic.shape, car_egopose_to_sensor.shape)

      # Forward pass
      with torch.no_grad():
        #([1, 1, 6, 3, 224, 480]) ([1, 1, 6, 3, 3]) ([1, 1, 6, 4, 4])
        output = trainer.model(image, intrinsics, extrinsics)
        figure_numpy = plot_prediction(image, output, trainer.cfg)
        os.makedirs('./output_vis', exist_ok=True)
        output_filename = os.path.join('./output_vis', os.path.basename(data_path).split('.')[0]) + '.png'
        Image.fromarray(figure_numpy).save(output_filename)
        print(f'Saved output in {output_filename}')
      '''

    '''
    # Load data
    for data_path in sorted(glob(os.path.join(EXAMPLE_DATA_PATH, '*.npz'))):
        data = np.load(data_path)
        image = torch.from_numpy(data['image']).to(device)
        intrinsics = torch.from_numpy(data['intrinsics']).to(device)
        extrinsics = torch.from_numpy(data['extrinsics']).to(device)
        #future_egomotions = torch.from_numpy(data['future_egomotion']).to(device)

        # Forward pass
        with torch.no_grad():
            #output = trainer.model(image, intrinsics, extrinsics, future_egomotions)
            output = trainer.model(image, intrinsics, extrinsics)

        figure_numpy = plot_prediction(image, output, trainer.cfg)
        os.makedirs('./output_vis', exist_ok=True)
        output_filename = os.path.join('./output_vis', os.path.basename(data_path).split('.')[0]) + '.png'
        Image.fromarray(figure_numpy).save(output_filename)
        print(f'Saved output in {output_filename}')
    '''

if __name__ == '__main__':
    #parser = ArgumentParser(description='Fiery visualisation')
    #parser.add_argument('--checkpoint', default='./fiery.ckpt', type=str, help='path to checkpoint')
    #args = parser.parse_args()
    #visualise_nuscence(args.checkpoint)

    checkpoint_path = 'fiery.ckpt'
    #checkpoint_path = '/home/igs/SSD/3Dobject/bev/fiery/fiery-master/checkpoints/epoch=25-step=11413.ckpt'
    #checkpoint_path = '/home/igs/SSD/3Dobject/bev/fiery/bev_model1130/checkpoints121/checkpoints/epoch=40-step=17998.ckpt'
    visualise_nuscence(checkpoint_path)

