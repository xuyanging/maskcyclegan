python train.py --config fiery/configs/baseline.yml DATASET.DATAROOT /home/igs/Desktop/nuscenc_mini
