#python visualise.py --checkpoint /home/igs/SSD/3Dobject/bev/fiery/fiery-master/checkpoints/epoch=25-step=11413.ckpt
#python visualise.py --checkpoint /home/igs/SSD/3Dobject/bev/fiery/fiery-master/fiery.ckpt
python visualise.py
