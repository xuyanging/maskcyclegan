import onnx
from onnx.tools import update_model_dims


input_names = {'input_0','inout_1','input_2'}
output_names = {'output_0','output_1'}

model = onnx.load('epoch7-step75007-sim.onnx')
onnx.checker.check_model(model)
input_0 = model.graph.input[0].name   # 1x1x6x3x224x480
input_1 = model.graph.input[1].name   # 1x1x6x3x3
input_2 = model.graph.input[2].name   # 1x1x6x4x4



variable_length_model = update_model_dims.update_inputs_outputs_dims(model,{input_0: [1, 6, 3, 224, 480],
                                                                            input_1: [1, 6, 3, 3],
                                                                            input_2: [1, 6, 4, 4]},
                                                                            {}) 