import netron
import os
model_path = 'epoch7-step75007-sim.onnx'
netron.start(model_path)