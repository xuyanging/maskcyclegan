import onnxruntime as rt
import cv2
import numpy as np
#import tensorflow as tf
#from vis_results import *
import copy
from PIL import Image
import time



def test_pytorch():
    img = cv2.imread("0088_RV.png")
    img = cv2.resize(img,[400,300])
    img = img.astype(np.float32)
    img = np.transpose(img, axes=[2, 0, 1])
    img = img.reshape([1] + list(img.shape))
    img = img/255
    sess = rt.InferenceSession("Unet-q2.onnx", providers=["CUDAExecutionProvider"])
    input_name = sess.get_inputs()[0].name
    output_name = sess.get_outputs()[0].name
    time_start=time.time()
    result = sess.run([output_name], {input_name: img})
    time_end=time.time()
    print("ONNX_pytorch")
    print('totally cost',time_end-time_start)
    #print(result[0])
    cv2.imwrite('onnx_results.jpg',result[0][0][0]*255)

test_pytorch()