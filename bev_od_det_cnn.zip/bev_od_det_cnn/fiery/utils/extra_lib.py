import torch
#from torch.linalg import det

def cof1(M,index):
    zs = M[:index[0]-1,:index[1]-1]
    ys = M[:index[0]-1,index[1]:]
    zx = M[index[0]:,:index[1]-1]
    yx = M[index[0]:,index[1]:]
    s = torch.cat((zs,ys),axis=1)
    x = torch.cat((zx,yx),axis=1)
    return det_self(torch.cat((s,x),axis=0))

# for tensorrt model
def det_2x2 (matrix):
    return matrix[0,0]*matrix[1,1]-matrix[0,1]*matrix[1,0]

def det_self(matrix):
    if matrix.shape[0]==2:
        return det_2x2(matrix)
    else:
        return matrix[0,2]*det_2x2(matrix[1:3,0:2]) - matrix[1,2]*det_2x2(torch.stack((matrix[0,0:2],matrix[2,0:2]),axis=0)
) + matrix[2,2]*det_2x2(matrix[0:2,0:2])



def inverse(M_all):
    results_all = torch.zeros((M_all.shape))
    for batch in range(M_all.shape[0]):
        for channel in range(M_all.shape[1]):
            result = torch.zeros((M_all.shape[2],M_all.shape[3]))
            M = M_all[batch,channel,:,:]
            for i in range(1,M.shape[0]+1):
                for j in range(1,M.shape[1]+1):
                    result[j-1][i-1] = pow(-1,i+j)*cof1(M,[i,j])
            results_all[batch,channel,:,:]=1.0/det_self(M)*result
           
    return results_all

#M = torch.rand(1,6,3,3)
#M = torch.FloatTensor([[1,2,-1],[2,3,4],[3,1,2]])
#print("torch.inverse results:", torch.inverse(M))
#print("inverse results:", inverse(M))

