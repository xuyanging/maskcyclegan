import torch
import torch.nn as nn
import pytorch_lightning as pl

from fiery.config import get_cfg
#from fiery.models.fiery import Fiery
from fiery.models.bev_model import Fiery
from fiery.losses import ProbabilisticLoss, SpatialRegressionLoss, SegmentationLoss ,WHLoss,FocalLoss, BinRotLoss
from fiery.metrics import IntersectionOverUnion, PanopticMetric
from fiery.utils.geometry import cumulative_warp_features_reverse
from fiery.utils.instance import predict_instance_segmentation_and_trajectories
from fiery.utils.visualisation import visualise_output

def _sigmoid(x):
  y = torch.clamp(x.sigmoid_(), min=1e-4, max=1-1e-4)
  return y

class TrainingModule(pl.LightningModule):
    def __init__(self, hparams):
        super().__init__()
        
        # see config.py for details
        self.hparams = hparams
        # pytorch lightning does not support saving YACS CfgNone
        cfg = get_cfg(cfg_dict=self.hparams)
        self.cfg = cfg
        self.n_classes = len(self.cfg.SEMANTIC_SEG.WEIGHTS)

        # Bird's-eye view extent in meters
        assert self.cfg.LIFT.X_BOUND[1] > 0 and self.cfg.LIFT.Y_BOUND[1] > 0
        self.spatial_extent = (self.cfg.LIFT.X_BOUND[1], self.cfg.LIFT.Y_BOUND[1])

        # Model
        self.model = Fiery(cfg)

        # Losses
        self.losses_fn = nn.ModuleDict()
        #[1.0, 2.0] True 0.25 0.95
        self.losses_fn['segmentation'] = SegmentationLoss(
            class_weights=torch.Tensor(self.cfg.SEMANTIC_SEG.WEIGHTS),
            use_top_k=self.cfg.SEMANTIC_SEG.USE_TOP_K,
            top_k_ratio=self.cfg.SEMANTIC_SEG.TOP_K_RATIO,
            future_discount=self.cfg.FUTURE_DISCOUNT,
        )

        # Uncertainty weighting
        self.model.segmentation_weight = nn.Parameter(torch.tensor(0.0), requires_grad=True)

        self.metric_iou_val = IntersectionOverUnion(self.n_classes)

        self.losses_fn['instance_center'] = SpatialRegressionLoss(
            norm=2, future_discount=self.cfg.FUTURE_DISCOUNT
        )

        self.losses_fn['object_wh'] = WHLoss()
        #self.losses_fn['object_angle'] = WHLoss()
        self.losses_fn['object_angle'] = BinRotLoss()
        
        #self.losses_fn['object_center'] = SpatialRegressionLoss(norm=2, future_discount=self.cfg.FUTURE_DISCOUNT)
        self.losses_fn['object_center'] = FocalLoss()

        self.losses_fn['instance_offset'] = SpatialRegressionLoss(
            norm=1, future_discount=self.cfg.FUTURE_DISCOUNT, ignore_index=self.cfg.DATASET.IGNORE_INDEX)

        # Uncertainty weighting
        self.model.centerness_weight = nn.Parameter(torch.tensor(0.0), requires_grad=True)
        self.model.offset_weight = nn.Parameter(torch.tensor(0.0), requires_grad=True)

        self.metric_panoptic_val = PanopticMetric(n_classes=self.n_classes)

        if self.cfg.INSTANCE_FLOW.ENABLED:
            self.losses_fn['instance_flow'] = SpatialRegressionLoss(
                norm=1, future_discount=self.cfg.FUTURE_DISCOUNT, ignore_index=self.cfg.DATASET.IGNORE_INDEX
            )
            # Uncertainty weighting
            self.model.flow_weight = nn.Parameter(torch.tensor(0.0), requires_grad=True)

        if self.cfg.PROBABILISTIC.ENABLED:
            self.losses_fn['probabilistic'] = ProbabilisticLoss()

        self.training_step_count = 0

    def shared_step(self, batch, is_train):
        image = batch['image']
        intrinsics = batch['intrinsics']
        extrinsics = batch['extrinsics']
        future_egomotion = batch['future_egomotion']

        wh_car = batch['wh_car']
        ind_car = batch['ind_car']
        reg_mask_car = batch['reg_mask_car']
        hm_car = batch['hm_car']
        '''
        print('image:  ',image.shape)  #[1, 1, 6, 3, 224, 480]
        print('intrinsics:  ', intrinsics.shape)  #[1, 1, 6, 3, 3]
        print('wh_car:  ', wh_car.shape)   #[1, 1, 128, 2]
        print('ind_car:  ', ind_car.shape) #[1, 1, 128]
        print('hm_car:  ', hm_car.shape)   #[1, 1, 200, 200]
        print('instance: ',batch['instance'].shape)  #[1, 1, 200, 200]
        print('segmentation:  ',batch['segmentation'].shape)  #[1, 1, 1, 200, 200]
        '''
        # Warp labels
        labels, future_distribution_inputs = self.prepare_future_labels(batch)
        #print('labels:-------------',labels.keys()) #['segmentation', 'instance', 'centerness', 'offset']
        # Forward pass
        #print('extrinsics:  ', image.shape, intrinsics.shape, extrinsics.shape)
        # ([1, 4, 6, 3, 224, 480]) ([1, 4, 6, 3, 3]) ([1, 4, 6, 4, 4])
        #output = self.model( image, intrinsics, extrinsics, future_egomotion, future_distribution_inputs )
        output = self.model(image, intrinsics, extrinsics)
        #print(output.keys())  #segmentation', 'instance_center', 'instance_offset', 'instance_flow']
        #print('output----:  ',output['segmentation'].shape,output['instance_center'].shape) #[2, 1, 2, 200, 200]  [2, 1, 1, 200, 200]
        #####
        # Loss computation
        #####
        loss = {}
        segmentation_factor = 1 / torch.exp(self.model.segmentation_weight)
        loss['segmentation'] = segmentation_factor * self.losses_fn['segmentation'](
            output['segmentation'], labels['segmentation']
        )
        loss['segmentation_uncertainty'] = 0.5 * self.model.segmentation_weight

        centerness_factor = 1 / (2*torch.exp(self.model.centerness_weight))
        loss['instance_center'] = centerness_factor * self.losses_fn['instance_center'](
            output['instance_center'], labels['centerness']
        )
        #print('instance_center centerness: ',output['instance_center'].shape, labels['centerness'].shape)
        #[2, 1, 1, 200, 200]  [2, 1, 1, 200, 200]

        offset_factor = 1 / (2*torch.exp(self.model.offset_weight))
        loss['instance_offset'] = offset_factor * self.losses_fn['instance_offset'](
            output['instance_offset'], labels['offset'])

        loss['centerness_uncertainty'] = 0.5 * self.model.centerness_weight
        loss['offset_uncertainty'] = 0.5 * self.model.offset_weight
        #print('loss weight:  ', centerness_factor.data, offset_factor.data, loss['centerness_uncertainty'].data,
        #      loss['offset_uncertainty'].data, self.model.centerness_weight.data, self.model.offset_weight.data)
        if self.cfg.INSTANCE_FLOW.ENABLED:
            flow_factor = 1 / (2*torch.exp(self.model.flow_weight))
            loss['instance_flow'] = flow_factor * self.losses_fn['instance_flow'](
                output['instance_flow'], labels['flow']
            )

            loss['flow_uncertainty'] = 0.5 * self.model.flow_weight

        if self.cfg.PROBABILISTIC.ENABLED:
            loss['probabilistic'] = self.cfg.PROBABILISTIC.WEIGHT * self.losses_fn['probabilistic'](output)

        #print('object_center hm_car:  ',output['object_center'].shape, batch['hm_car'].shape)
        # ([2, 1, 1, 200, 200])  ([2, 1, 1, 200, 200])
        object_centerness_factor = 1 / (2*torch.exp(self.model.centerness_weight))
        #loss['object_center'] = object_centerness_factor * self.losses_fn['object_center'](
        #    output['object_center'], batch['hm_car'])
        
        output['object_center'] = _sigmoid(output['object_center'])
        loss['object_center'] =  self.losses_fn['object_center'](output['object_center'], batch['hm_car'])
        
        #print('object_wh wh_car:  ',output['object_wh'].shape, batch['wh_car'].shape, batch['ind_car'].shape, batch['reg_mask_car'].shape)
        #[2, 1, 2, 200, 200] [2, 1, 128, 2] [2, 1, 128] [2, 1, 128]
        
        #print('ind_car: ',batch['ind_car'])
        loss['object_wh'] =   self.losses_fn['object_wh'](
            output['object_wh'], batch['wh_car'],batch['ind_car'],batch['reg_mask_car']
        )
        '''
        loss['object_angle'] =   self.losses_fn['object_angle'](
            output['object_angle'], batch['angle_car'],batch['ind_car'],batch['reg_mask_car']
        )
        '''
        loss['object_angle'] = self.losses_fn['object_angle'](output['object_angle'], batch['rot_mask'],
                                  batch['ind_car'], batch['rotbin'],batch['rotres'])
        #print('object_angle:  ',loss['object_angle'])
        # Metrics
        if not is_train:
            seg_prediction = output['segmentation'].detach()
            seg_prediction = torch.argmax(seg_prediction, dim=2, keepdims=True)
            self.metric_iou_val(seg_prediction, labels['segmentation'])

            pred_consistent_instance_seg = predict_instance_segmentation_and_trajectories(
                output, compute_matched_centers=False)

            self.metric_panoptic_val(pred_consistent_instance_seg, labels['instance'])

        return output, labels, loss

    def prepare_future_labels(self, batch):
        labels = {}
        future_distribution_inputs = []

        segmentation_labels = batch['segmentation']
        instance_center_labels = batch['centerness']
        instance_offset_labels = batch['offset']
        instance_flow_labels = batch['flow']
        gt_instance = batch['instance']
        future_egomotion = batch['future_egomotion']
        #print('before segmentation_labels:  ',segmentation_labels.shape)  #torch.Size([2, 1, 1, 200, 200])
        # Warp labels to present's reference frame
        segmentation_labels = cumulative_warp_features_reverse(
            segmentation_labels[:, (self.model.receptive_field - 1):].float(),
            future_egomotion[:, (self.model.receptive_field - 1):],
            mode='nearest', spatial_extent=self.spatial_extent,
        ).long().contiguous()
        labels['segmentation'] = segmentation_labels
        future_distribution_inputs.append(segmentation_labels)
        #print('after segmentation_labels:  ', segmentation_labels.shape)
        # Warp instance labels to present's reference frame
        gt_instance = cumulative_warp_features_reverse(
            gt_instance[:, (self.model.receptive_field - 1):].float().unsqueeze(2),
            future_egomotion[:, (self.model.receptive_field - 1):],
            mode='nearest', spatial_extent=self.spatial_extent,
        ).long().contiguous()[:, :, 0]
        labels['instance'] = gt_instance

        instance_center_labels = cumulative_warp_features_reverse(
            instance_center_labels[:, (self.model.receptive_field - 1):],
            future_egomotion[:, (self.model.receptive_field - 1):],
            mode='nearest', spatial_extent=self.spatial_extent,
        ).contiguous()
        labels['centerness'] = instance_center_labels

        instance_offset_labels = cumulative_warp_features_reverse(
            instance_offset_labels[:, (self.model.receptive_field- 1):],
            future_egomotion[:, (self.model.receptive_field - 1):],
            mode='nearest', spatial_extent=self.spatial_extent,
        ).contiguous()
        labels['offset'] = instance_offset_labels

        future_distribution_inputs.append(instance_center_labels)
        future_distribution_inputs.append(instance_offset_labels)

        if self.cfg.INSTANCE_FLOW.ENABLED:
            instance_flow_labels = cumulative_warp_features_reverse(
                instance_flow_labels[:, (self.model.receptive_field - 1):],
                future_egomotion[:, (self.model.receptive_field - 1):],
                mode='nearest', spatial_extent=self.spatial_extent,
            ).contiguous()
            labels['flow'] = instance_flow_labels

            future_distribution_inputs.append(instance_flow_labels)

        if len(future_distribution_inputs) > 0:
            future_distribution_inputs = torch.cat(future_distribution_inputs, dim=2)

        return labels, future_distribution_inputs

    def visualise(self, labels, output, batch_idx, prefix='train'):
        visualisation_video = visualise_output(labels, output, self.cfg)
        name = f'{prefix}_outputs'
        if prefix == 'val':
            name = name + f'_{batch_idx}'
        self.logger.experiment.add_video(name, visualisation_video, global_step=self.training_step_count, fps=2)

    def training_step(self, batch, batch_idx):
        output, labels, loss = self.shared_step(batch, True)
        self.training_step_count += 1
        if (self.training_step_count % 2 == 0) and (torch.cuda.current_device() == 0):
          loss_seg = round(float(loss['segmentation'].cpu().detach().numpy()), 4)
          loss_ins_center = round(float(loss['instance_center'].cpu().detach().numpy()), 4)
          loss_obj_center = round(float(loss['object_center'].cpu().detach().numpy()), 4)
          loss_obj_wh = round(float(loss['object_wh'].cpu().detach().numpy()), 4)
          loss_obj_angle = round(float(loss['object_angle'].cpu().detach().numpy()), 4)
          print('loss_seg: ', loss_seg, ' loss_ins_center: ', loss_ins_center, ' loss_obj_center: ', loss_obj_center, ' loss_obj_wh: ', loss_obj_wh, ' loss_obj_angle: ', loss_obj_angle)
        #print('training_step_count:  ',self.training_step_count)
        for key, value in loss.items():
            self.logger.experiment.add_scalar(key, value, global_step=self.training_step_count)
        if self.training_step_count % self.cfg.VIS_INTERVAL == 0:
            self.visualise(labels, output, batch_idx, prefix='train')
        return sum(loss.values())

    def validation_step(self, batch, batch_idx):
        output, labels, loss = self.shared_step(batch, False)
        for key, value in loss.items():
            self.log('val_' + key, value)

        if batch_idx == 0:
            self.visualise(labels, output, batch_idx, prefix='val')

    def shared_epoch_end(self, step_outputs, is_train):
        # log per class iou metrics
        class_names = ['background', 'dynamic']
        if not is_train:
            scores = self.metric_iou_val.compute()
            for key, value in zip(class_names, scores):
                self.logger.experiment.add_scalar('val_iou_' + key, value, global_step=self.training_step_count)
            self.metric_iou_val.reset()

        if not is_train:
            scores = self.metric_panoptic_val.compute()
            for key, value in scores.items():
                for instance_name, score in zip(['background', 'vehicles'], value):
                    if instance_name != 'background':
                        self.logger.experiment.add_scalar(f'val_{key}_{instance_name}', score.item(),
                                                          global_step=self.training_step_count)
            self.metric_panoptic_val.reset()

        self.logger.experiment.add_scalar('segmentation_weight',
                                          1 / (torch.exp(self.model.segmentation_weight)),
                                          global_step=self.training_step_count)
        self.logger.experiment.add_scalar('centerness_weight',
                                          1 / (2 * torch.exp(self.model.centerness_weight)),
                                          global_step=self.training_step_count)
        self.logger.experiment.add_scalar('offset_weight', 1 / (2 * torch.exp(self.model.offset_weight)),
                                          global_step=self.training_step_count)
        if self.cfg.INSTANCE_FLOW.ENABLED:
            self.logger.experiment.add_scalar('flow_weight', 1 / (2 * torch.exp(self.model.flow_weight)),
                                              global_step=self.training_step_count)

    def training_epoch_end(self, step_outputs):
        self.shared_epoch_end(step_outputs, True)

    def validation_epoch_end(self, step_outputs):
        self.shared_epoch_end(step_outputs, False)

    def configure_optimizers(self):
        params = self.model.parameters()
        optimizer = torch.optim.Adam(
            params, lr=self.cfg.OPTIMIZER.LR, weight_decay=self.cfg.OPTIMIZER.WEIGHT_DECAY
        )

        return optimizer
