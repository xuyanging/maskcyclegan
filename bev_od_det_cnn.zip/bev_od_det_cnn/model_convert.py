import onnx
from onnx.tools import update_model_dims
import torch
from fiery.trainer import TrainingModule
#import thop
#from thop import clever_format
import onnxruntime as rt
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error
import time





def Test_mae(r_torch, r_onnx):
    name_list = ['segmentation','instance_center','instance_offset','object_center','object_wh','object_angle']
    for i in range(len(name_list)):
        res_torch = r_torch[name_list[i]]
        res_onnx = r_onnx[i]
        error = mean_absolute_percentage_error(res_torch.detach().numpy().flatten(),res_onnx.flatten())
        print(name_list[i],' error: ',error)


model_path = 'epoch=7-step=75007.ckpt'

device = torch.device('cpu')
trainer = TrainingModule.load_from_checkpoint(model_path, strict=True)
trainer.eval()
trainer.freeze()
trainer.to(device)
model = trainer.model
'''
cfg = model.cfg

_, valloader = prepare_dataloaders(cfg)

for i, batch in enumerate(valloader):
    preprocess_batch(batch, device)
    image = batch['image']
    intrinsics = batch['intrinsics']
    extrinsics = batch['extrinsics']
    future_egomotion = batch['future_egomotion']

    batch_size = image.shape[0]
'''
model = model.to(device)

Test_efficiency = True
Test_accuracy = True


image = torch.rand(1,1,6,3,224,480).to(device)
intrinsics = torch.rand(1,1,6,3,3).to(device)
extrinsics = torch.rand(1,1,6,4,4).to(device)

#image = torch.rand(6,3,224,480).to(device)
#intrinsics = torch.rand(6,3,3).to(device)
#extrinsics = torch.rand(6,4,4).to(device)



torch.onnx.export(model, (image,intrinsics,extrinsics), 'epoch7-step75007.onnx', opset_version=11, verbose=True, export_params=True, do_constant_folding=True)




if Test_accuracy:

    time_start=time.time()
    torch_result = model(image,intrinsics,extrinsics)
    time_end=time.time()
    print('Torch totally cost',time_end-time_start)

    #print('output: ',output.shape)
    
    sess = rt.InferenceSession("epoch7-step75007.onnx", providers=["CUDAExecutionProvider"])

    input_1 = sess.get_inputs()[0].name
    input_2 = sess.get_inputs()[1].name
    input_3 = sess.get_inputs()[2].name

    output_1 = sess.get_outputs()[0].name
    output_2 = sess.get_outputs()[1].name
    output_3 = sess.get_outputs()[2].name
    output_4 = sess.get_outputs()[3].name
    output_5 = sess.get_outputs()[4].name
    output_6 = sess.get_outputs()[5].name
    
    time_start=time.time()
    onnx_result = sess.run([output_1,output_2,output_3,output_4,output_5,output_6], 
                    {input_1: image.numpy(),input_2:intrinsics.numpy(),input_3:extrinsics.numpy()})
    time_end=time.time()
    print('ONNX totally cost',time_end-time_start)


    Test_mae(torch_result, onnx_result)


if Test_efficiency:
    
    flops,params = thop.profile(model,inputs=(image,intrinsics,extrinsics))
    flops, params = clever_format([flops, params], "%.3f")

